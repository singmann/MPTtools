
mptmem_secondderivatives_llfct <- function( us = NULL, tCatDat = NULL, 
  tCovDat = NULL, probmatrix = NULL, catmatrix = NULL, type_mpt = NULL, 
  iSIGMA = NULL, MU = NULL, GAM = NULL, S = NULL, LAM = NULL, PSI = NULL,
  matjj = NULL, posjj = NULL, matpp = NULL, pospp = NULL, usiSIGMA = NULL ) 
{
  #- set derivative to zero:
  res <- 0
  
  #- formulas for the derivatives:
  if ( matjj == "MU" & matpp == "MU" ) { 
    p <- nrow( MU )
    #- 1jj - matrix:
    ONEjj <- matrix( 0, nrow = p, ncol = 1 ) 
    ONEjj[ posjj[1], posjj[2] ] <- 1
    #- 1pp - matrix:
    ONEpp <- matrix( 0, nrow = p, ncol = 1 ) 
    ONEpp[ pospp[1], pospp[2] ] <- 1
    #- derivative: 
    res <- -t(ONEpp)%*%iSIGMA%*%ONEjj
  }
  
  if ( matjj == "SIGMA" & matpp == "SIGMA" ) {
    #- 1jj - matrix and derivative
    p <- nrow( iSIGMA )
    ONEjj <- diag( 0, p ) 
    ONEjj[ posjj[1], posjj[2] ] <- 1  
    dSIGMAjj <- ONEjj + t( ONEjj ) - ONEjj %*% ONEjj
    #- 1pp - matrix and derivative
    ONEpp <- diag( 0, p ) 
    ONEpp[ pospp[1], pospp[2] ] <- 1  
    dSIGMApp <- ONEpp + t( ONEpp ) - ONEpp %*% ONEpp
    #- true ll derivative:
    pt1 <-  0.5*sum( (iSIGMA%*%dSIGMAjj)*(iSIGMA%*%dSIGMApp) )
    pt2 <- -1.0*( usiSIGMA%*%( (dSIGMAjj%*%iSIGMA%*%dSIGMApp)%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( matjj == "S" & matpp == "S" ) {
    #- 1jj - matrix and derivative
    p <- nrow( iSIGMA )
    ONEjj <- diag( 0, p ) 
    ONEjj[ posjj[1], posjj[2] ] <- 1  
    dSIGMAjj <- t( ONEjj ) %*% S + t( S ) %*% ONEjj
    #- 1pp - matrix and derivative
    ONEpp <- diag( 0, p ) 
    ONEpp[ pospp[1], pospp[2] ] <- 1  
    dSIGMApp <- t( ONEpp ) %*% S + t( S ) %*% ONEpp
    #- additonal term:
    dSIGMAjjpp <- t( ONEjj ) %*% ONEpp + t( ONEpp ) %*% ONEjj
    #- true ll derivative:
    tmp <- dSIGMAjj%*%iSIGMA%*%dSIGMApp
    pt1 <- 0.5*( sum( iSIGMA*( tmp - dSIGMAjjpp ) ) )
    pt2 <- ( usiSIGMA%*%( ( 0.5*dSIGMAjjpp - tmp ) %*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( matjj == "LAM" & matpp == "LAM" ) {
    #- 1jj - matrix and derivative
    p <- nrow( LAM )
    ONEjj <- matrix( 0, nrow = p, ncol = 1 )
    ONEjj[ posjj[1], posjj[2] ] <- 1  
    dSIGMAjj <- ONEjj %*% t( LAM ) + LAM %*% t( ONEjj )
    #- 1pp - matrix and derivative
    ONEpp <- matrix( 0, nrow = p, ncol = 1 )
    ONEpp[ pospp[1], pospp[2] ] <- 1  
    dSIGMApp <- ONEpp %*% t( LAM ) + LAM %*% t( ONEpp )
    #- additonal term:
    dSIGMAjjpp <- ONEjj %*% t( ONEpp ) + ONEpp %*% t( ONEjj )
    #- true ll derivative:
    tmp <- dSIGMAjj%*%iSIGMA%*%dSIGMApp
    pt1 <- 0.5*( sum( iSIGMA*( tmp - dSIGMAjjpp ) ) )
    pt2 <- ( usiSIGMA%*%( ( 0.5*dSIGMAjjpp - tmp ) %*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( matjj == "PSI" & matpp == "PSI" ) {
    #- 1jj - matrix and derivative
    p <- nrow( iSIGMA )
    ONEjj <- diag( 0, p ) 
    ONEjj[ posjj[1], posjj[2] ] <- 1  
    dSIGMAjj <- ONEjj
    #- 1pp - matrix and derivative
    ONEpp <- diag( 0, p ) 
    ONEpp[ pospp[1], pospp[2] ] <- 1  
    dSIGMApp <- ONEpp
    #- true ll derivative:
    pt1 <-  0.5*sum( (iSIGMA%*%dSIGMAjj)*(iSIGMA%*%dSIGMApp) )
    pt2 <- -1.0*( usiSIGMA%*%( (dSIGMAjj%*%iSIGMA%*%dSIGMApp)%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( (matjj == "SIGMA" & matpp == "MU") | (matjj == "MU" & matpp == "SIGMA") ) {
    
    #- matrix and derivative for SIGMA
    p <- nrow( iSIGMA )
    ONE_SIG <- diag( 0, p ) 
    if ( matjj == "SIGMA" ) {
      ONE_SIG[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_SIG[ pospp[1], pospp[2] ] <- 1 
    }   
    dSIGMA <- ONE_SIG + t( ONE_SIG ) - ONE_SIG %*% ONE_SIG
    #- 1pp - matrix and derivative
    p <- nrow( MU )
    ONE_MU <- matrix( 0, nrow = p, ncol = 1 ) 
    if ( matjj == "MU" ) {
      ONE_MU[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_MU[ pospp[1], pospp[2] ] <- 1 
    }  
    dMU <- ONE_MU
    #- true ll derivative:
    res <- -usiSIGMA%*%( ( dSIGMA%*%iSIGMA )%*% dMU )
  }

  if ( (matjj == "S" & matpp == "MU") | (matjj == "MU" & matpp == "S") ) {
    
    #- matrix and derivative for SIGMA
    p <- nrow( iSIGMA )
    ONE_S <- diag( 0, p ) 
    if ( matjj == "S" ) {
      ONE_S[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_S[ pospp[1], pospp[2] ] <- 1 
    }   
    dSIGMA <- t( ONE_S ) %*% S + t( S ) %*% ONE_S
    #- 1pp - matrix and derivative
    p <- nrow( MU )
    ONE_MU <- matrix( 0, nrow = p, ncol = 1 ) 
    if ( matjj == "MU" ) {
      ONE_MU[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_MU[ pospp[1], pospp[2] ] <- 1 
    }  
    dMU <- ONE_MU
    #- true ll derivative:
    res <- -usiSIGMA%*%( ( dSIGMA%*%iSIGMA )%*% dMU )
  }

  if ( (matjj == "PSI" & matpp == "MU") | (matjj == "MU" & matpp == "PSI") ) {
    
    #- matrix and derivative for SIGMA
    p <- nrow( iSIGMA )
    ONE_PSI <- diag( 0, p ) 
    if ( matjj == "S" ) {
      ONE_PSI[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_PSI[ pospp[1], pospp[2] ] <- 1 
    }   
    dSIGMA <- ONE_PSI
    #- 1pp - matrix and derivative
    p <- nrow( MU )
    ONE_MU <- matrix( 0, nrow = p, ncol = 1 ) 
    if ( matjj == "MU" ) {
      ONE_MU[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_MU[ pospp[1], pospp[2] ] <- 1 
    }  
    dMU <- ONE_MU
    #- true ll derivative:
    res <- -usiSIGMA%*%( ( dSIGMA%*%iSIGMA )%*% dMU )
  }

  if ( (matjj == "LAM" & matpp == "MU") | (matjj == "MU" & matpp == "LAM") ) {
    
    #- matrix and derivative for SIGMA
    p <- nrow( LAM )
    ONE_LAM <- matrix( 0, nrow = p, ncol = 1 )
    if ( matjj == "LAM" ) {
      ONE_LAM[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_LAM[ pospp[1], pospp[2] ] <- 1 
    }   
    dSIGMA <- ONE_LAM %*% t( LAM ) + LAM %*% t( ONE_LAM )
    #- 1pp - matrix and derivative
    p <- nrow( MU )
    ONE_MU <- matrix( 0, nrow = p, ncol = 1 ) 
    if ( matjj == "MU" ) {
      ONE_MU[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_MU[ pospp[1], pospp[2] ] <- 1 
    }  
    dMU <- ONE_MU
    #- true ll derivative:
    res <- -usiSIGMA%*%( ( dSIGMA%*%iSIGMA )%*% dMU )
  }

  if ( (matjj == "LAM" & matpp == "PSI") | (matjj == "PSI" & matpp == "LAM") ) {
    #- 1-matrix and derivative for LAM
    p <- nrow( LAM )
    ONE_LAM <- matrix( 0, nrow = p, ncol = 1 )
    if ( matjj == "LAM" ) {
      ONE_LAM[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_LAM[ pospp[1], pospp[2] ] <- 1 
    }   
    dLAM <- ONE_LAM %*% t( LAM ) + LAM %*% t( ONE_LAM )
    #- 1-matrix and derivative for PSI
    p <- nrow( iSIGMA )
    ONE_PSI <- diag( 0, p ) 
    if ( matjj == "S" ) {
      ONE_PSI[ posjj[1], posjj[2] ] <- 1  
    } else {
      ONE_PSI[ pospp[1], pospp[2] ] <- 1 
    }   
    dPSI <- ONE_PSI
    #- true ll derivative:
    pt1 <-  0.5*sum( (iSIGMA%*%dLAM)*(iSIGMA%*%dPSI) )
    pt2 <- -1.0*( usiSIGMA%*%( (dLAM%*%iSIGMA%*%dPSI)%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  #- output
  return( res )
} 

##################

mptmem_hessian_agh <- function( tCatDat = NULL, tCovDat = NULL, tPerDat = NULL, 
  raneffs = NULL, parm_list = NULL, matname = NULL, position = NULL, probmatrix = NULL, 
  catmatrix = NULL, type_mpt = NULL, agh_list = NULL, SIGMA = NULL, iSIGMA = NULL, 
  MU = NULL, GAM = NULL, S = NULL, LAM = NULL, PSI = NULL, use_rcpp = NULL )
{
    #- get quadrature information
    tmp.pts <- agh_list[["tmp.pts"]]
    tmp.exp <- agh_list[["tmp.exp"]] # exp-transformed quadrature points
    tmp.wghexp <- agh_list[["tmp.wghexp"]] 
    #- get information on the nmber of dimensions of SIGMA
    Q <- ncol( SIGMA )
    #- estimate mode of theta and hessian matrix of theta
    MODE <- raneffs[["MODE"]]
    CHOL <- raneffs[["CHOL"]]
    DET  <- raneffs[["DET"]] 
    #- compute transformed quadrature points
    tmp.pts <- tmp.pts%*%CHOL
    tmp.pts <- sweep( tmp.pts, 2, MODE, "+") 
    #- compute normal density values of quadratute points given Gom
    tmp.den <- mvtnorm::dmvnorm( tmp.pts, tPerDat, SIGMA )
    nop  <- max( position[,3] )
    if ( use_rcpp ) {
      out <- mptmem_hessian_data_rcpp( pts = tmp.pts, tCatDat = tCatDat, 
        tCovDat = tCovDat, tPerDat = tPerDat, matname = matname, 
        position = position, probmatrix = probmatrix, catmatrix = catmatrix, 
        type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, 
        S = S, LAM = LAM, PSI = PSI, wghexp = tmp.wghexp, 
        den = tmp.den, qmc = FALSE )
      outf <- out[["outf"]]
      outg <- out[["outg"]]
      outh <- out[["outh"]]
    } else {
      #- now comes the part for the gradient:
      npp  <- nrow( position ) 
      nPts <- nrow( tmp.pts )
      outf <- matrix( 0, nrow = nPts, ncol = 1 )
      outg <- matrix( 0, nrow = nPts, ncol = nop )
      outh <- matrix( 0, nrow = nPts, ncol = nop*nop )
      #- iterate
      for ( ii in 1:nPts ) {
        #- get point
        Pii <- tmp.pts[ii,]    
        #- -------------------------------------------------
        #-   compute conditional likelihood value for Pii
        #- -------------------------------------------------
        res <- mptmem_llfct_data( us = Pii, tCatDat = tCatDat, probmatrix = probmatrix, 
          catmatrix = catmatrix, type_mpt = type_mpt )
        #- get weight and density values to compute marginal loglik person
        wii <- tmp.wghexp[ ii ]
        dii <- tmp.den[ ii ]
        fii <- res*wii*dii
        #- -----------------------------------
        #-    obtain gradient for this point
        #- -----------------------------------
        #- some pre computations:
        usiSIGMA <- t( Pii - tPerDat )%*%( iSIGMA )
        #- make tmp_der:
        tmp_grad <- rep( 0, nop )
        for ( jj in 1:npp ) {
          #- get information for derivative for parm jj:
          mat <- matname[jj] 
          pos <- position[jj,1:2]
          idx <- position[jj,3]
          #- compute derivative for parm jj:                                       
          der <- mptmem_derivatives_llfct( us = Pii, tCatDat = tCatDat, 
            tCovDat = tCovDat, probmatrix = probmatrix, catmatrix = catmatrix, 
            type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, 
            S = S, LAM = LAM, PSI = PSI, mat = mat, pos = pos, 
            usiSIGMA = usiSIGMA )
          tmp_grad[ idx ] <- tmp_grad[ idx ] + der
        }
        #- ----------------------------------
        #-    obtain hessian for this point
        #- ----------------------------------
        #- make tmp_hessian:
        tmp_hess <- matrix( 0, nop, nop )
        for ( jj in 1:npp ) {
          #- get information for parm jj:
          matjj <- matname[jj] 
          posjj <- position[jj,1:2]
          idxjj <- position[jj,3]
          derjj <- tmp_grad[idxjj]
          for ( pp in jj:npp ) {
            #- get information for parm pp:
            matpp <- matname[pp] 
            pospp <- position[pp,1:2]
            idxpp <- position[pp,3]
            derpp <- tmp_grad[idxpp]
            #- compute second derivative:
            hes <- mptmem_secondderivatives_llfct( us = Pii, 
              tCatDat = tCatDat, tCovDat = tCovDat, probmatrix = probmatrix, 
              catmatrix = catmatrix, type_mpt = type_mpt, iSIGMA = iSIGMA, 
              MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI, 
              matjj = matjj, posjj = posjj, matpp = matpp, 
              pospp = pospp, usiSIGMA = usiSIGMA )
            tmp_hess[ idxjj, idxpp ] <- tmp_hess[ idxjj, idxpp ] + (hes + derjj*derpp)
            tmp_hess[ idxpp, idxjj ] <- tmp_hess[ idxjj, idxpp ] 
          }
        }
        outf[ ii, 1 ] <- fii
        outg[ ii, ] <- tmp_grad*fii
        outh[ ii, ] <- as.vector( tmp_hess )*fii        
      }
    }
    #- final computations:
    outf <- colSums( outf ) 
    ll_fcti <-  (2*pi)^(Q/2) *  sqrt( DET ) * outf
    outg <- colSums( outg ) 
    ll_gradi <- (2*pi)^(Q/2) *  sqrt( DET ) * outg
    outh <- colSums( outh ) 
    ll_hessi <- (2*pi)^(Q/2) *  sqrt( DET ) * outh
    ll_hessi <- matrix( ll_hessi, ncol = nop, byrow = TRUE )
    #- return result:
    fin <- list( ll_fcti = as.numeric( ll_fcti ), ll_gradi = ll_gradi, 
      ll_hessi = ll_hessi  )
    return( fin )
}

##################

mptmem_hessian_qmc <- function( tCatDat = NULL, tCovDat = NULL, tPerDat = NULL, 
  raneffs = NULL, parm_list = NULL, matname = NULL, position = NULL, probmatrix = NULL, 
  catmatrix = NULL, type_mpt = NULL, qmc_pts = NULL, SIGMA = NULL, iSIGMA = NULL, 
  MU = NULL, GAM = NULL, S = NULL, LAM = NULL, PSI = NULL, use_rcpp = NULL )
{
    #- get information on the number of dimensions of SIGMA:
    Q <- ncol( SIGMA )
    #- estimate mode of theta and hessian matrix of theta:
    MODE <- raneffs[["MODE"]]
    CHOL <- raneffs[["CHOL"]]
    iHESS <- raneffs[["iHESS"]]
    #- transform pts:
    qmc_pts <- qmc_pts%*%CHOL
    qmc_pts <- sweep( qmc_pts, 2, MODE, "+") 
    #- compute normal density values of draws
    tmp_den1 <- mvtnorm::dmvnorm( qmc_pts, tPerDat, SIGMA )
    tmp_den2 <- mvtnorm::dmvnorm( qmc_pts, MODE, iHESS )
    nop  <- max( position[,3] )
    if ( use_rcpp ) {
      wghexp <- den <- rep( 1, length( tmp_den2 ) )
      out <- mptmem_hessian_data_rcpp( pts = qmc_pts, tCatDat = tCatDat, tCovDat = tCovDat,
      tPerDat = tPerDat, matname = matname, position = position, 
      probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
      iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
      wghexp= wghexp, den = den, qmc = TRUE )
      outf <- out[["outf"]]
      outg <- out[["outg"]]
      outh <- out[["outh"]]
    } else {
      #- now comes the part for the gradient:
      npp  <- nrow( position ) 
      nPts <- nrow( qmc_pts )
      outf <- matrix( 0, nrow = nPts, ncol = 1 )
      outg <- matrix( 0, nrow = nPts, ncol = nop )
      outh <- matrix( 0, nrow = nPts, ncol = nop*nop )
      #- iterate
      for ( ii in 1:nPts ) {
        #- get point
        Pii <- qmc_pts[ii,]   
        #- -------------------------------------------------
        #-   compute conditional likelihood value for Pii
        #- -------------------------------------------------
        res <- mptmem_llfct_data( us = Pii, tCatDat = tCatDat, probmatrix = probmatrix, 
          catmatrix = catmatrix, type_mpt = type_mpt )       
        #- get weight and density values to compute marginal loglik person
        fii <- res
        #- -----------------------------------
        #-    obtain gradient for this point
        #- -----------------------------------
        #- some pre computations:
        usiSIGMA <- t( Pii - tPerDat )%*%( iSIGMA )
        #- make tmp_der:
        tmp_grad <- rep( 0, nop )
        for ( jj in 1:npp ) {
          #- get information for derivative for parm jj:
          mat <- matname[jj] 
          pos <- position[jj,1:2]
          idx <- position[jj,3]
          #- compute derivative for parm jj:                                       
          der <- mptmem_derivatives_llfct( us = Pii, tCatDat = tCatDat, 
            tCovDat = tCovDat, probmatrix = probmatrix, catmatrix = catmatrix, 
            type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, 
            S = S, LAM = LAM, PSI = PSI, mat = mat, pos = pos, 
            usiSIGMA = usiSIGMA )
          tmp_grad[ idx ] <- tmp_grad[ idx ] + der
        }
        #- ----------------------------------
        #-    obtain hessian for this point
        #- ----------------------------------
        #- make tmp_hessian:
        tmp_hess <- matrix( 0, nop, nop )
        for ( jj in 1:npp ) {
          #- get information for parm jj:
          matjj <- matname[jj] 
          posjj <- position[jj,1:2]
          idxjj <- position[jj,3]
          derjj <- tmp_grad[jj]
          for ( pp in jj:npp ) {
            #- get information for parm pp:
            matpp <- matname[pp] 
            pospp <- position[pp,1:2]
            idxpp <- position[pp,3]
            derpp <- tmp_grad[pp]
            #- compute second derivative:
            hes <- mptmem_secondderivatives_llfct( us = Pii, 
              tCatDat = tCatDat, tCovDat = tCovDat, probmatrix = probmatrix, 
              catmatrix = catmatrix, type_mpt = type_mpt, iSIGMA = iSIGMA, 
              MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI, 
              matjj = matjj, posjj = posjj, matpp = matpp, 
              pospp = pospp, usiSIGMA = usiSIGMA )
            tmp_hess[ jj, pp ] <- tmp_hess[ jj, pp ] + (hes + derjj*derpp)
            tmp_hess[ pp, jj ] <- tmp_hess[ jj, pp ] 
          }
        }
        outf[ ii, 1 ] <- fii
        outg[ ii, ] <- tmp_grad
        outh[ ii, ] <- as.vector( tmp_hess )         
      }
    }
    #- final computations:
    ll_fcti <-  mean( outf[,1]*tmp_den1*(1/tmp_den2) )
    ll_gradi <- apply( outg, 2, function(x) x*( outf[,1]*tmp_den1*(1/tmp_den2) ) ) 
    ll_gradi <- colMeans( ll_gradi )
    ll_hessi <- apply( outh, 2, function(x) x*( outf[,1]*tmp_den1*(1/tmp_den2) ) ) 
    ll_hessi <- colMeans( ll_hessi )
    ll_hessi <- matrix( ll_hessi, ncol = nop, byrow = TRUE )
    #- return result:
    fin <- list( ll_fcti = as.numeric( ll_fcti ), ll_gradi = ll_gradi, 
      ll_hessi = ll_hessi  )
    return( fin )
}

#- function to compute marginal log-Likelihood

mptmem_hessian <- function( parm = NULL, parm_list = NULL, parm_table = NULL, catDat = NULL, 
  perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = NULL, type_mpt = NULL, 
  type_sigma = NULL, raneff_list = NULL, agh_list = NULL, qmc_pts = NULL, use_rcpp = NULL )
{
  #- include parm in parm_list:
  parm_list <- mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  S <- parm_list[["S"]] 
  LAM <- parm_list[["LAM"]]
  PSI <- parm_list[["PSI"]]
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {  
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    SIGMA <- LAM %*% t(LAM) + PSI
  }
  iSIGMA <- base::solve( SIGMA )
  MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- perDat <- MUmat } # perDat is just a placeholder
  #- transform parm_table:
  matname <- parm_table$mat
  position <- as.matrix( parm_table[,c("row","col","index")])
  #- Let's go:
	gi <- zi <- hi <- vector( "list", T )
	for ( tt in 1:T ) {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- get a person's covariate data:
    tCovDat <- perDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "AGH" ) { 
      int <- mptmem_hessian_agh( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, agh_list = agh_list, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )
    } else if ( method == "QMC" ) {
      int <- mptmem_hessian_qmc( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, qmc_pts = qmc_pts, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )  
    }
    #- save in the correct list
    gi[[ tt ]] <- int[["ll_fcti"]]
    zi[[ tt ]] <- int[["ll_gradi"]] 
    hi[[ tt ]] <- int[["ll_hessi"]] 
  }
  #- compute hessian:
  hessian <- lapply( 1:length( hi ), function(tt) { 
    (1/gi[[tt]]^2)*( gi[[tt]]*hi[[tt]] - zi[[tt]]%*%t( zi[[tt]] ) ) } )  
  hessian <- Reduce("+", hessian ) 
  #- compute gradient:
  gradient <- lapply( 1:length( gi ), function(tt) { zi[[tt]]*1/gi[[tt]] })  
  gradient <- Reduce("+", gradient ) 
  #- compute log-likelihood:
  llfct <- lapply( gi, function(i) log(i) )
  llfct <- Reduce("+", llfct )
  #- outcome:
  out <- list( "llfct"=-2*llfct, "gradient"=-2*gradient, "hessian"=-2*hessian ) 
  return( out )
}