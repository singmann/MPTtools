
mptmem_derivatives_llfct <- function( us = NULL, tCatDat = NULL, tCovDat = NULL, 
  probmatrix = NULL, catmatrix = NULL, type_mpt = NULL, iSIGMA = NULL, MU = NULL, 
  GAM = NULL, S = NULL, LAM = NULL, PSI = NULL, mat = NULL, pos = NULL, usiSIGMA = NULL ) 
{
  #- set derivative to zero:
  res <- 0
  #- formulas for the derivatives:
  if ( mat == "MU" ) { 
    #- 1_ij - matrix:
    p <- nrow( MU )
    ONE_ij <- matrix( 0, nrow = p, ncol = 1 ) 
    ONE_ij[ pos[1], pos[2] ] <- 1
    #- derivative: 
    res <- usiSIGMA%*%ONE_ij
  }
  
  if ( mat == "GAM" ) { 
    #- 1_ij - matrix:
    p <- nrow( GAM )
    q <- ncol( GAM )
    ONE_ij <- matrix( 0, nrow = p, ncol = q ) 
    ONE_ij[ pos[1], pos[2] ] <- 1
    #- derivative: 
    res <- usiSIGMA%*%(ONE_ij%*%tCovDat)
  }

  if ( mat == "SIGMA" ) {
    #- 1_ij - matrix
    p <- nrow( iSIGMA )
    ONE_ij <- diag( 0, p ) 
    ONE_ij[ pos[1], pos[2] ] <- 1  
    #- derivative: 
    dSIGMA <- ONE_ij + t( ONE_ij ) - ONE_ij %*% ONE_ij
    #- true ll derivative:
    pt1 <- -0.5*sum( iSIGMA * dSIGMA )
    pt2 <-  0.5*( usiSIGMA%*%( dSIGMA%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( mat == "S" ) {
    #- 1_ij - matrix
    p <- nrow( iSIGMA )
    ONE_ij <- diag( 0, p ) 
    ONE_ij[ pos[1], pos[2] ] <- 1  
    #- derivative: 
    dSIGMA <- t( ONE_ij ) %*% S + t( S ) %*% ONE_ij
    #- true ll derivative:
    pt1 <- -0.5*sum( iSIGMA * dSIGMA )
    pt2 <-  0.5*( usiSIGMA%*%( dSIGMA%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( mat == "LAM" ) {
    #- 1_ij - matrix
    p <- nrow( LAM )
    ONE_ij <- matrix( 0, nrow = p, ncol = 1 )
    ONE_ij[ pos[1], pos[2] ] <- 1  
    #- derivative: 
    dSIGMA <- ONE_ij %*% t( LAM ) + LAM %*% t( ONE_ij )
    #- true ll derivative:
    pt1 <- -0.5*sum( iSIGMA * dSIGMA )
    pt2 <-  0.5*( usiSIGMA%*%( dSIGMA%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  if ( mat == "PSI" ) {
    #- 1_ij - matrix
    p <- nrow( iSIGMA )
    ONE_ij <- diag( 0, p ) 
    ONE_ij[ pos[1], pos[2] ] <- 1  
    #- derivative: 
    dSIGMA <- ONE_ij
    #- true ll derivative:
    pt1 <- -0.5*sum( iSIGMA * dSIGMA )
    pt2 <-  0.5*( usiSIGMA%*%( dSIGMA%*%t(usiSIGMA) ) )
    res <-  pt1 + pt2   
  }

  #- output
  return( res )
} 

##################

mptmem_gradient_laplace <- function( tCatDat = NULL, tCovDat = NULL, tPerDat = NULL, 
  raneffs = NULL, parm_list = NULL, matname = NULL, position = NULL, probmatrix = NULL, 
  catmatrix = NULL, type_mpt = NULL, SIGMA = NULL, iSIGMA = NULL, MU = NULL, GAM = NULL, 
  S = NULL, LAM = NULL, PSI = NULL, use_rcpp = NULL )
{
  #- get quadrature information:
  Q <- ncol( SIGMA )
  #- estimate mode of theta and hessian matrix of theta:
  MODE <- raneffs[["MODE"]]
  DET  <- raneffs[["DET"]] 
  #- compute the normal density value for the mode:
  tmp.den <- mvtnorm::dmvnorm( MODE, tPerDat, SIGMA )
  tmp.wghexp <- rep( 1, length( tmp.den) )
  #- now comes the part for the gradient: 
  tmp.pts <- matrix( MODE, nrow = 1 )
  #- now comes the part for the gradient:
  if ( use_rcpp ) {
    out <- mptmem_gradient_data_rcpp( pts = tmp.pts, tCatDat = tCatDat, tCovDat = tCovDat,
      tPerDat = tPerDat, matname = matname, position = position, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, 
      S = S, LAM = LAM, PSI = PSI, wghexp = tmp.wghexp, den = tmp.den, qmc = FALSE )
  } else {
    nop <- max( position[,3] )
    npp <- nrow( position ) 
    nPts <- nrow( tmp.pts )
    out <- matrix( 0, nrow = nPts, ncol = nop + 1 )
    #- iterate
    for ( ii in 1:nPts ) {
      #- get point
      Pii <- tmp.pts[ii,]
      #- compute the conditional likelihood value for Pii:
      res <- mptmem_llfct_data( us = Pii, tCatDat = tCatDat, probmatrix = probmatrix, 
        catmatrix = catmatrix, type_mpt = type_mpt )
      #- get weight and density values to compute marginal loglik person
      wii <- tmp.wghexp[ ii ]
      dii <- tmp.den[ ii ]
      fii <- res*wii*dii
      #- some pre computations:
      usiSIGMA <- t( Pii - tPerDat )%*%( iSIGMA )    
      #- make tmp_der:
      tmp_der <- rep( 0, nop )
      #- obtain the gradient for this point:
      for ( jj in 1:npp ) {
        #- get information for derivative
        mat <- matname[jj] 
        pos <- position[jj,]
        idx <- position[jj,3]
        if ( mat == "MU" ) {
          der <- usiSIGMA[ pos[1] ]
        } else {  
          #- compute derivative                                        
          der <- mptmem_derivatives_llfct( us = Pii, tCatDat = tCatDat, tCovDat = tCovDat, 
            probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
            iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
            S = S, LAM = LAM, PSI = PSI, mat = mat, pos = pos, usiSIGMA = usiSIGMA )
        }
        tmp_der[ idx ] <- tmp_der[ idx ] + der*fii 
      }
      out[ ii, ] <- c( fii, tmp_der )
    }
  }
  #- compute Laplace approximation:
  ll_gradi <- (2*pi)^(Q/2) *  sqrt( DET ) * out[-1]
  ll_fcti <-  (2*pi)^(Q/2) *  sqrt( DET ) * out[ 1] 
  #- return result:
  fin <- list( ll_gradi = ll_gradi, ll_fcti = as.numeric( ll_fcti ) )
  return( fin )
}

mptmem_gradient_agh <- function( tCatDat = NULL, tCovDat = NULL, tPerDat = NULL, 
  raneffs = NULL, parm_list = NULL, matname = NULL, position = NULL, probmatrix = NULL, 
  catmatrix = NULL, type_mpt = NULL, agh_list = NULL, SIGMA = NULL, iSIGMA = NULL, 
  MU = NULL, GAM = NULL, S = NULL, LAM = NULL, PSI = NULL, use_rcpp = NULL )
{
    #- get quadrature information
    tmp.pts <- agh_list[["tmp.pts"]]
    tmp.exp <- agh_list[["tmp.exp"]] # exp-transformed quadrature points
    tmp.wghexp <- agh_list[["tmp.wghexp"]] 
    #- get information on the nmber of dimensions of SIGMA
    Q <- ncol( SIGMA )
    #- estimate mode of theta and hessian matrix of theta
    MODE <- raneffs[["MODE"]]
    CHOL <- raneffs[["CHOL"]]
    DET  <- raneffs[["DET"]] 
    #- compute transformed quadrature points
    tmp.pts <- tmp.pts%*%CHOL
    tmp.pts <- sweep( tmp.pts, 2, MODE, "+") 
    #- compute normal density values of quadratute points given Gom
    tmp.den <- mvtnorm::dmvnorm( tmp.pts, tPerDat, SIGMA )
    if ( use_rcpp ) {
      out <- mptmem_gradient_data_rcpp( pts = tmp.pts, tCatDat = tCatDat, tCovDat = tCovDat,
        tPerDat = tPerDat, matname = matname, position = position, probmatrix = probmatrix, 
        catmatrix = catmatrix, type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, 
        S = S, LAM = LAM, PSI = PSI, wghexp= tmp.wghexp, den = tmp.den, qmc = FALSE )
    } else {
      #- now comes the part for the gradient:
      nop <- max( position[,3] )
      npp <- nrow( position ) 
      nPts <- nrow( tmp.pts )
      out <- matrix( 0, nrow = nPts, ncol = nop + 1 )
      #- iterate
      for ( ii in 1:nPts ) {
        #- get point
        Pii <- tmp.pts[ii,]
        #- compute the conditional likelihood value for Pii:
        res <- mptmem_llfct_data( us = Pii, tCatDat = tCatDat, probmatrix = probmatrix, 
          catmatrix = catmatrix, type_mpt = type_mpt )
        #- get weight and density values to compute marginal loglik person
        wii <- tmp.wghexp[ ii ]
        dii <- tmp.den[ ii ]
        fii <- res*wii*dii
        out[ ii, 1 ] <- fii
        #- some pre computations:
        usiSIGMA <- t( Pii - tPerDat )%*%( iSIGMA )
        #- make tmp_der:
        tmp_der <- rep( 0, nop )
        #- obtain the gradient for this point:
        for ( jj in 1:npp ) {
          #- get information for derivative
          mat <- matname[jj] 
          pos <- position[jj,1:2]
          idx <- position[jj,3]
          #- test for MU:
          if ( mat == "MU" ) {
            der <- usiSIGMA[ pos[1] ]
          } else {      
            #- compute derivative                                        
            der <- mptmem_derivatives_llfct( us = Pii, tCatDat = tCatDat, tCovDat = tCovDat, 
              probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
              iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
              mat = mat, pos = pos, usiSIGMA = usiSIGMA )
          }
          tmp_der[ idx ] <- tmp_der[ idx ] + der*fii 
        }
        out[ ii, ] <- c( fii, tmp_der )         
      }
    }
    #- final computations:
    tmp <- colSums( out ) 
    ll_gradi <- (2*pi)^(Q/2) *  sqrt( DET ) * tmp[-1]
    ll_fcti <-  (2*pi)^(Q/2) *  sqrt( DET ) * tmp[ 1] 
    #- return result:
    fin <- list( ll_gradi = ll_gradi, ll_fcti = as.numeric( ll_fcti ) )
    return( fin )
}

mptmem_gradient_qmc <- function( tCatDat = NULL, tCovDat = NULL, tPerDat = NULL, 
  raneffs = NULL, parm_list = NULL, matname = NULL, position = NULL, probmatrix = NULL, 
  catmatrix = NULL, type_mpt = NULL, qmc_pts = NULL, SIGMA = NULL, iSIGMA = NULL, 
  MU = NULL, GAM = NULL, S = NULL, LAM = NULL, PSI = NULL, use_rcpp = NULL )
{
  #- get quadrature information
  Q <- ncol( SIGMA )
  #- get mode and hessian matrix:
  MODE <- raneffs[["MODE"]]
  CHOL <- raneffs[["CHOL"]]
  iHESS <- raneffs[["iHESS"]]
  #- transform pts:
  qmc_pts <- qmc_pts%*%CHOL
  qmc_pts <- sweep( qmc_pts, 2, MODE, "+") 
  #- compute normal density values of draws
  tmp_den1 <- mvtnorm::dmvnorm( qmc_pts, tPerDat, SIGMA )
  tmp_den2 <- mvtnorm::dmvnorm( qmc_pts, MODE, iHESS )
  if ( use_rcpp ) {
    wghexp <- den <- rep( 1, length( tmp_den2 ) )
    out <- mptmem_gradient_data_rcpp( pts = qmc_pts, tCatDat = tCatDat, tCovDat = tCovDat,
      tPerDat = tPerDat, matname = matname, position = position, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, 
      S = S, LAM = LAM, PSI = PSI, wghexp= wghexp, den = den, qmc = TRUE )
  } else {
    #- now comes the part for the gradient:
    nop <- max( position[,3] )
    npp <- nrow( position ) 
    nPts <- nrow( qmc_pts )
    out <- matrix( 0, nrow = nPts, ncol = nop + 1 )
    #- iterate
    for ( ii in 1:nPts ) {
      #- get point
      Pii <- qmc_pts[ii,]
      #- compute the conditional likelihood value for Pii:
      fii <- mptmem_llfct_data( us = Pii, tCatDat = tCatDat, probmatrix = probmatrix, 
        catmatrix = catmatrix, type_mpt = type_mpt )
      #- some pre computations:
      usiSIGMA <- t( Pii - tPerDat )%*%( iSIGMA )
      #- make tmp_der:
      tmp_der <- rep( 0, nop )
      #- obtain the gradient for this point:
      for ( jj in 1:npp ) {
        #- get information for derivative
        mat <- matname[jj] 
        pos <- position[jj,]
        idx <- position[jj,3]
        #- test for MU:
        if ( mat == "MU" ) {
          der <- usiSIGMA[ pos[1] ]
        } else {      
          #- compute derivative                                        
          der <- mptmem_derivatives_llfct( us = Pii, tCatDat = tCatDat, tCovDat = tCovDat, 
            probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
            iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
            mat = mat, pos = pos, usiSIGMA = usiSIGMA )
        }
        #- compute derivative  
        tmp_der[ idx ] <- tmp_der[ idx ] + der
      }
      out[ ii, ] <- c( fii, tmp_der )          
    }
  }
  #- compute estimator:
  ll_fcti <-  mean( out[,1]*tmp_den1*(1/tmp_den2) )
  ll_gradi <- apply( out[,-1], 2, function(x) x*( out[,1]*tmp_den1*(1/tmp_den2) ) ) 
  ll_gradi <- colMeans( ll_gradi )
  fin <- list( ll_gradi = ll_gradi, ll_fcti = as.numeric( ll_fcti ) )
  return( fin )
}

#- function to compute marginal log-Likelihood

mptmem_gradient <- function( parm = NULL, parm_list = NULL, parm_table = NULL, catDat = NULL, 
  perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = NULL, type_mpt = NULL, 
  raneff_list = NULL, agh_list = NULL, qmc_pts = NULL, use_rcpp = NULL, output = 0, 
  type_sigma = NULL )
{
  #- include parm in parm_list:
  parm_list <- mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  S <- parm_list[["S"]] 
  LAM <- parm_list[["LAM"]]
  PSI <- parm_list[["PSI"]]
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {  
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    SIGMA <- LAM %*% t(LAM) + PSI
  } 
  iSIGMA <- base::solve( SIGMA )
  MU  <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- perDat <- MUmat } # perDat is just a placeholder
  #- transform parm_table:
  matname <- parm_table$mat
  position <- as.matrix( parm_table[,c("row","col","index")])
  #- Let's go:
	gi <- zi <- vector( "list", T )
	for ( tt in 1:T ) {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- get a person's covariate data:
    tCovDat <- perDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "Laplace" ) {
      int <- mptmem_gradient_laplace( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )
    } else if ( method == "AGH" ) { 
      int <- mptmem_gradient_agh( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, agh_list = agh_list, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )
    } else if ( method == "QMC" ) {
      int <- mptmem_gradient_qmc( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, qmc_pts = qmc_pts, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )  
    }
    #- save in the correct list
    gi[[ tt ]] <- int[["ll_fcti"]]
    zi[[ tt ]] <- int[["ll_gradi"]]   
  }
  #- compute gradient:
  gradient <- lapply( 1:length( gi ), function(tt) { zi[[tt]]*1/gi[[tt]] })  
  gradient <- Reduce("+", gradient ) 
  #- compute log-likelihood:
  llfct <- lapply( gi, function(i) log(i) )
  llfct <- Reduce("+", llfct )
  #- outcome and hessian:
  if ( output == 1) {
    out <- list( "objective"=-2*llfct, "gradient"=-2*gradient )  
  } else if ( output == 0 ) {
    out <- -2*gradient
  }
  return( out )
}