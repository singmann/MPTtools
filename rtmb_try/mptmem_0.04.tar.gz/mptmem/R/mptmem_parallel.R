
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mptmem_llfct_parallel <- function( parm = NULL, parm_list = NULL, parm_table = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = "AGH", 
  type_mpt = NULL, type_sigma = NULL, raneff_list = NULL, agh_list = NULL, qmc_pts = NULL, 
  use_rcpp = TRUE, output = 0 )
{
  #- include parm in parm_list:
  parm_list <- mptmem::mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {
    S <- parm_list[["S"]]   
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    LAM <- parm_list[["LAM"]]
    PSI <- parm_list[["PSI"]]
    SIGMA <- LAM %*% t(LAM) + PSI
  }
  MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- MUmat }
  #- let's go:
  tmp_ll <- vector( "list", T )
  tmp_ll <- foreach::foreach( tt = seq(1, T, 1 ) ) %dopar% {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "Laplace" ) {
      tmp_ll[ tt ] <- mptmem::mptmem_llfct_laplace( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, SIGMA = SIGMA,
        use_rcpp = use_rcpp )
    } else if ( method == "AGH" ) { 
      tmp_ll[ tt ] <- mptmem::mptmem_llfct_agh( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        agh_list = agh_list, probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA, use_rcpp = use_rcpp )
    } else if ( method == "QMC" ) {
      tmp_ll[ tt ] <- mptmem::mptmem_llfct_qmc( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        qmc_pts = qmc_pts, probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA, use_rcpp = use_rcpp )        
    }
  }     
  #- transform tmp_ll to a vector:
  llfct <- do.call( "rbind", tmp_ll )
  #- take the log and sum the elements in tmp.res
  llfct <- sum( log( llfct ) )
  #- outcome
  #if ( is.infinite( llfct ) | is.na( llfct ) ) { llfct <- 100000 }
  return( -2*llfct )
}

#- %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mptmem_gradient_parallel <- function( parm = NULL, parm_list = NULL, parm_table = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = "AGH", 
  type_mpt = NULL, type_sigma = NULL, raneff_list = NULL, agh_list = NULL, qmc_pts = NULL, 
  use_rcpp = NULL, output = 0 )
{
  #- include parm in parm_list:
  parm_list <- mptmem::mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  S <- parm_list[["S"]] 
  LAM <- parm_list[["LAM"]]
  PSI <- parm_list[["PSI"]]
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {  
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    SIGMA <- LAM %*% t(LAM) + PSI
  } 
  iSIGMA <- MASS::ginv( SIGMA )
  MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- perDat <- MUmat } # perDat is just a placeholder
  #- transform parm_table:
  matname <- parm_table$mat
  position <- as.matrix( parm_table[,c("row","col","index")])
  #- Let's go:
  gr <- vector( "list", T )
  gr <- foreach::foreach( tt = seq(1, T, 1 ) ) %dopar% {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- get a person's covariate data:
    tCovDat <- perDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "Laplace" ) {
      int <- mptmem::mptmem_gradient_laplace( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )
    } else if ( method == "AGH" ) { 
      int <- mptmem::mptmem_gradient_agh( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, agh_list = agh_list, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )
    } else if ( method == "QMC" ) {
      int <- mptmem::mptmem_gradient_qmc( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, qmc_pts = qmc_pts, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )  
    }
    #- save in the correct list
    return( list( gi = int[["ll_fcti"]], zi = int[["ll_gradi"]] ) )   
  }
  #- compute gradient:
  gradient <- lapply( gr, function(tt) { tt[["zi"]]*1/tt[["gi"]] })   
  gradient <- Reduce("+", gradient ) 
  #- compute log-likelihood:
  llfct <- lapply( gr, function(tt) log( tt[["gi"]] ) )
  llfct <- Reduce("+", llfct )
  #- outcome and hessian:
  if ( output == 1 ) {
    #if ( is.infinite( llfct ) | is.na( llfct ) ) { llfct <- -100000 }
    out <- list( "objective"=-2*llfct, "gradient"=-2*gradient )  
  } else if ( output == 0 ) {
    out <- -2*gradient
  }
  return( out )
}

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mptmem_hessian_parallel <- function( parm = NULL, parm_list = NULL, parm_table = NULL, catDat = NULL, 
  perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = "AGH", type_mpt = NULL, 
  type_sigma = NULL, raneff_list = NULL, agh_list = NULL, qmc_pts = NULL, use_rcpp = NULL )
{
  #- include parm in parm_list:
  parm_list <- mptmem::mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  S <- parm_list[["S"]] 
  LAM <- parm_list[["LAM"]]
  PSI <- parm_list[["PSI"]]
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {  
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    SIGMA <- LAM %*% t(LAM) + PSI
  } 
  iSIGMA <- base::solve( SIGMA )
  MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- perDat <- MUmat } # perDat is just a placeholder
  #- transform parm_table:
  matname <- parm_table$mat
  position <- as.matrix( parm_table[,c("row","col","index")])
  #- Let's go:
  gr <- vector( "list", T )
  gr <- foreach::foreach( tt = seq(1, T, 1 ) ) %dopar% {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- get a person's covariate data:
    tCovDat <- perDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "AGH" ) { 
      int <- mptmem::mptmem_hessian_agh( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, agh_list = agh_list, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )
    } else if ( method == "QMC" ) {
      int <- mptmem::mptmem_hessian_qmc( tCatDat = tCatDat, tCovDat = tCovDat, tPerDat = tPerDat, 
        raneffs = raneffs, parm_list = parm_list, matname = matname, position = position, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, qmc_pts = qmc_pts, 
        SIGMA = SIGMA, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
        use_rcpp = use_rcpp )  
    }
    #- save in the correct list
    return( list( gi = int[["ll_fcti"]], zi = int[["ll_gradi"]], hi = int[["ll_hessi"]] ) ) 
  }
  #- compute hessian:
  hessian <- lapply( gr, function(tt) { 
    (1/tt[["gi"]]^2)*( tt[["gi"]]*tt[["hi"]] - tt[["zi"]]%*%t( tt[["zi"]] ) ) } )  
  hessian <- Reduce("+", hessian ) 
  #- compute gradient:
  gradient <- lapply( gr, function(tt) { tt[["zi"]]*1/tt[["gi"]] })  
  gradient <- Reduce("+", gradient ) 
  #- compute log-likelihood:
  llfct <- lapply( gr, function( tt ) log( tt[["gi"]] ) )
  llfct <- Reduce("+", llfct )
  #- outcome:
  out <- list( "llfct"=-2*llfct, "gradient"=-2*gradient, "hessian"=-2*hessian ) 
  return( out )
}

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mptmem_modelstats_parallel <- function( parm = NULL, parm_list = NULL, parm_table = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = NULL, 
  type_mpt = NULL, type_sigma = NULL, raneff_list = NULL, agh_list = NULL, 
  qmc_pts = NULL, use_rcpp = NULL, dev = NULL, hessian = NULL, with_ses = TRUE, 
  est_hessian = TRUE )
{
  #- default for warning_vcov:
  warning_vcov <- NULL
  P <- length( parm )
  #- adapt parm and parm_table if type_sigma %in% c("CD","FA")
  if ( type_sigma %in% c("CD","FA") ) {
    tmp <- mptmem::mptmem_modelstats_sigmaback( parm = parm, parm_list = parm_list, 
      parm_table = parm_table, type_sigma = type_sigma )
    parm_table <- tmp$parm_table
    parm <- tmp$parm 
    type_sigma <- "UN"
  }
  #- compute standard errors: 
  if ( with_ses ) {
    if ( is.null( hessian ) ) {
      if ( est_hessian ) {
        hessian <- nloptr::nl.jacobian( x0 = parm, fn = mptmem_gradient_parallel, 
          parm_list = parm_list, parm_table = parm_table, catDat = catDat, 
          perDat = perDat, probmatrix = probmatrix, catmatrix = catmatrix, 
          raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
          method = method, type_mpt = type_mpt, type_sigma = type_sigma,
          use_rcpp = use_rcpp, output = 0 )
      } else {
        hessian <- mptmem_hessian_parallel( parm = parm, parm_list = parm_list, 
          parm_table = parm_table, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
          agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp )$hessian
      }
    }
    tmp.ses <- mptmem_utils_compute_ses( hessian = hessian )
    warning_vcov <- tmp.ses$warning_vcov
    vcov <- tmp.ses$vcov
    se   <- tmp.ses$se
  } 

  #- we have to match the parm and the ses to the correct entries in parm_table:
  parm_table$se <- parm_table$est <- NA
  for ( ii in 1:P ) {
    idx <- which( parm_table$index == ii )
    parm_table[ idx, ]$est <- parm[ii]
    parm_table[ idx, ]$se <- se[ii]
  }
  parm_table$z <- parm_table$est/parm_table$se
  parm_table$p <- 2 * pnorm(-abs( parm_table$z ) )
  parm_table$lCI <- parm_table$est - 1.96*parm_table$se
  parm_table$uCI <- parm_table$est + 1.96*parm_table$se

  #- add fixed parms:
  idx <- which( !( is.na( parm_table$fixed ) ) )
  if ( length( idx ) > 0L ) {
    parm_table[idx,]$est <- parm_table[idx,]$fixed
  }

  #- compute fit measures:
  logLik <- -0.5*dev 
  Deviance <- dev
  aic <- dev + 2*P
  bic <- dev + 2*P*log( sum( catDat ) )

  #- include final parm in parm_list:
  parm_list <- mptmem::mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  
  #- output:
  out <- list( parm_table = parm_table, parm_list = parm_list, vcov = vcov, 
    logLik = logLik, Deviance = Deviance, aic = aic, bic = bic, 
    warning_vcov = warning_vcov )
  return( out )
}

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mptmem_linesearch_parallel <- function( parm = NULL, parm_list = NULL, parm_table = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, 
  method = NULL, type_mpt = NULL, type_sigma = NULL, raneff_list = NULL, agh_list = NULL, 
  qmc_pts = NULL, use_rcpp = NULL, output = NULL, incr = NULL, 
  ls_init_alpha = NULL, ls_tau = NULL, ls_tol = NULL, ls_iter_max = 10, 
  dev_old = NULL )
{
  #- everything for the line-search algorithm:
  ls_iter_no <- 0
  ls_alpha <- ls_init_alpha 
  iterate_line_search <- TRUE
  #- iterations
  while ( iterate_line_search ) {  
    #- make line search step
    ls_alpha <- ls_alpha * ls_tau
    incr <- incr * ls_alpha
    parm_new <- parm - incr
    #- compute new loglik-value with pen-term ( Qnew )
    dev_new <- mptmem_llfct_parallel( parm = parm_new, parm_list = parm_list, 
      parm_table = parm_table, catDat = catDat, perDat = perDat, 
      probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
      type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
      agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp, output = 0 )
    #- compare...
    if ( ls_iter_no > ls_iter_max ){ iterate_line_search <- FALSE }
    if ( dev_new <= dev_old ) { iterate_line_search <- FALSE }
    #- increase counter
    ls_iter_no <- ls_iter_no + 1
  }
  # if ( ls_iter_no > ls_iter_max ) { parm_new <- parm - 0.2 }
  #- output
  res <- list( parm_new = parm_new, dev_new = dev_new, incr = incr, 
    ls_iter_no = ls_iter_no, ls_alpha = ls_alpha )
  return( res )
}


# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

mptmem_optimize_parallel <- function( parm_table = NULL, parm_list = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, 
  method = NULL, type_mpt = NULL, type_sigma = NULL, use_rcpp = NULL, 
  control = NULL )
{
  #- collect arguments for internal optimizer:
  optimizer <- control[["opt_method"]]
  method_control_list <- control[["method_control_list"]]
  #- make quadrature or qmc points:
  noDim <- dim( parm_list[["SIGMA"]] )[1]
  if ( method == "AGH" ) {
    agh_list <- mptmem_getquadpoints( nGH = control$nGH, dimension = noDim )
    qmc_pts <- NULL
  } else if ( method == "QMC" ) {
    agh_list <- NULL
    qmc_pts <- mptmem_getqmcpoints( n = control$qmcSample, dimension = noDim, 
      type = control$qmcType ) 
  } else { agh_list <- qmc_pts <- NULL }
  #- collect arguments for external optimizing:
  maxit_out   <- control$maxit_out
  x_tol_out   <- control$x_tol_out
  fx_tol_out  <- control$fx_tol_out
  verbose_out <- control$verbose_out
  #- some final things:
  parm_new <- parm_table[ attr( parm_table, "parm_idx" ), "starts"]
  idx      <- which( ! is.na( parm_table$index ) )
  parm_table_small <- parm_table[idx,]
  ub <- parm_table[ attr( parm_table, "parm_idx" ), "up"]
  lb <- parm_table[ attr( parm_table, "parm_idx" ), "low"]
  #- things for the algorithm: 
  diterate <- TRUE
  diter    <- 0
  dev_new  <- 0
  hessian  <- NULL
  warning_raneff <- 0
  #- start the optimizer:
  while ( diterate ) {
    #- old parm_vector:  
    parm_old <- parm_new
    dev_old <- dev_new            
    #- Step 1: get random effect estimates:
    raneff_list <- suppressWarnings( tryCatch( { 
      mptmem_getmodes( parm = parm_old, parm_table = parm_table_small, 
      parm_list = parm_list, catDat = catDat, perDat = perDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt, type_sigma = type_sigma ) },
      error = function(e) { NULL },
      warning = function(w) { NULL } ) )
    #- error handling:
    if ( is.null( raneff_list ) ) {
      parm_new <- parm_old
      dev_new  <- dev_old
      warning_raneff <- 1
      break
    }
    #- Step 2: within optimizing:
    if ( optimizer == "nlminb" ) {
      tmp_res <- stats::nlminb( start = parm_old, objective = mptmem_llfct_parallel, 
        gradient = mptmem_gradient_parallel, control = method_control_list, parm_list = parm_list, 
        parm_table = parm_table_small, catDat = catDat, perDat = perDat, probmatrix = probmatrix, 
        catmatrix = catmatrix, method = method, type_mpt = type_mpt, type_sigma = type_sigma,
        raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
        use_rcpp = use_rcpp, output = 0 )
      #- get updated values:
      parm_new <- tmp_res$par
      dev_new  <- tmp_res$objective
    } 
    if ( optimizer == "nloptr" ) {
      if ( method_control_list$algorithm %in% c("NLOPT_LD_LBFGS","NLOPT_LD_CCSAQ") ) {
        tmp_res <- nloptr::nloptr( x0 = parm_old, eval_f = mptmem_gradient_parallel, 
          lb = lb, ub = ub, opts = method_control_list, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, 
          raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
          use_rcpp = use_rcpp, output = 1 )
      } else if ( method_control_list$algorithm %in% c("NLOPT_LN_BOBYQA","NLOPT_LN_SBPLX","NLOPT_LN_PRAXIS") ) {
        tmp_res <- nloptr::nloptr( x0 = parm_old, eval_f = mptmem_llfct_parallel, 
          lb = lb, ub = ub, opts = method_control_list, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, 
          raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
          use_rcpp = use_rcpp, output = 0 )
      }
      parm_new <- tmp_res$solution
      dev_new  <- tmp_res$objective   
    } 
    if ( optimizer == "newton_raphson") {
      convcrit_inn <- method_control_list$convcrit_nr
      maxit_inn    <- method_control_list$maxit_nr
      diterate_inn <- TRUE
      parm_new_inn <- parm_old
      # start newton_raphson:
      while ( diterate_inn ) {
        #- make output
        if ( method_control_list$verbose_inn ) {
          xx_inn <- as.character()
          tb_inn <- c( round( parm_new_inn, 4 ) )
          for (j in 1:length(tb_inn)) { xx_inn <- paste0(xx_inn, sprintf(" %g", tb_inn[j])) }
            h1 <- paste0("parms = ", xx_inn )
          cat(h1, "\n")
          utils::flush.console()
        }
        #- get parm
        parm_old_inn <- parm_new_inn
        #- compute hessian, gradient and ll_old
        tmp <- mptmem_hessian_parallel( parm = parm_old_inn, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
          agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp )
        dev_old_inn <- tmp[["llfct"]]
        grad        <- tmp[["gradient"]]
        hessian     <- tmp[["hessian"]]  
        #hessian     <- mptmem_utils_check_hessian( hessian = hessian )
        incr <- solve( hessian, grad )
        #- make line search and update parameter:
        incr <- vcov%*%grad
        lsearch <- mptmem_linesearch_parallel( parm = parm_old_inn, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
          agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp, output = 0, 
          incr = incr, ls_init_alpha = 2, ls_tau = 0.5, ls_tol = 0, ls_iter_max = 10, 
          dev_old = dev_old_inn )
        parm_new_inn <- lsearch[["parm_new"]]
        #- check convergence:
        delta <- max( abs( parm_new_inn - parm_old_inn ) )
        if ( delta < convcrit_inn | diter > maxit_inn ) {  
          diterate_inn <- FALSE
        } 
      }
      parm_new <- parm_new_inn
      dev_new <- lsearch[["dev_new"]]
    }
    # if ( optimizer == "gd") {
    #   tmp_res <- snoptim::snoptim( start = parm_old, fn = mptmem_llfct_parallel, 
    #     gr = mptmem_gradient_parallel, 
    #     control = method_control_list[names(method_control_list)!="algorithm"], 
    #     lb = lb, ub = ub,
    #     type = method_control_list$algorithm,
    #     parm_list = parm_list, parm_table = parm_table_small, catDat = catDat, 
    #     perDat = perDat, probmatrix = probmatrix, catmatrix = catmatrix, 
    #     method = method, type_mpt = type_mpt, , type_sigma = type_sigma,
    #     raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
    #     use_rcpp = use_rcpp, output = 0 )
    #   parm_new <- tmp_res$solution
    #   dev_new  <- tmp_res$fval  
    # }
    #- set diter:     
    diter <- diter + 1
    #- check convergence:
    dev_crit  <- abs( dev_new - dev_old )/dev_new
    parm_crit <- max( abs( parm_new - parm_old ) )
    if ( parm_crit < x_tol_out | dev_crit < fx_tol_out | diter > maxit_out ) {  
      diterate <- FALSE
    } 
    #- make output
    if ( verbose_out ) {
      xx <- as.character()
      tb <- c( round( parm_new, 4 ) )
      for (j in 1:length(tb)) { xx <- paste0(xx, sprintf(" %g", tb[j])) }
      h1 <- paste0("Deviance = " , round( dev_new , 2 ), 
                   " | parms = ", xx )
      cat(h1, "\n")
      utils::flush.console()
    }
  }
  #- output:
  if ( !diterate ) {
    conv <- 0
    mstats <- mptmem_modelstats_parallel( parm = parm_new, parm_list = parm_list, 
      parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
      probmatrix = probmatrix, 
      catmatrix = catmatrix, method = method, type_mpt = type_mpt, 
      type_sigma = type_sigma, 
      raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
      use_rcpp = use_rcpp, dev = dev_new, hessian = hessian, 
      with_ses = control$with_ses, est_hessian = control$est_hessian )
    vcov         <- mstats$vcov 
    logLik       <- mstats$logLik
    aic          <- mstats$aic
    bic          <- mstats$bic
    Deviance     <- mstats$Deviance
    parm_table   <- mstats$parm_table
    parm_list    <- mstats$parm_list
    warning_vcov <- mstats$warning_vcov
  } else { 
    conv <- 1; 
    parm_table$est <- parm_table$se <- parm_table$z <- NA;
    vcov <- logLik <- se <- aic <- bic <- Deviance <- NA;
  }
  res <- list( coef = parm_new, vcov = vcov, logLik = logLik, aic = aic, 
    bic = bic, Deviance = Deviance, conv = conv, warning_vcov = warning_vcov, 
    warning_raneff= warning_raneff, parm_table = parm_table, parm_list = parm_list, 
    agh_list = agh_list, qmc_pts = qmc_pts, raneff_list = raneff_list )
  return( res )
}
