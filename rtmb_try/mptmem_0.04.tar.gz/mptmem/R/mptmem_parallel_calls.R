
mptmem_startParallel <- function( parallel = TRUE, control = NULL )
{
  #- check availability of parallel and doParallel packages
  if( !all( requireNamespace("parallel", quietly = TRUE),
            requireNamespace("doParallel", quietly = TRUE ) ) ) {
    stop("You need 'parallel' and 'doParallel' for parallelization.")
  }     
     
  #- set default parallel functionality depending on system OS:
  #  snow functionality on Windows OS vs. multicore functionality 
  #  on Unix-like systems (Unix/Linux & Mac OSX)
  if(.Platform$OS.type == "windows") {
    parallelType <- "snow"
  } else { 
    parallelType <- "multicore"
  }

  #- get the current number of cores available
  numCores <- parallel::detectCores()

  #- reduce numCores by at least 1 core:
  numCores <- numCores - control$delta_parallel

  #- add some attributes:
  attr(parallel, "type")  <- parallelType
  attr(parallel, "cores") <- numCores

  # start "parallel backend":
  if( parallelType == "snow" ) { 
    # snow functionality on Unix-like systems & Windows:
    cl <- parallel::makeCluster(numCores, type = "PSOCK")
    attr(parallel, "cluster") <- cl
    # export parent environment:
    varlist <- ls(envir = parent.frame(), all.names = TRUE)
    varlist <- varlist[varlist != "..."]
    parallel::clusterExport( cl, varlist = varlist,envir = parent.frame() )
    # export global environment (workspace)
    parallel::clusterExport(cl, varlist = ls( envir = globalenv(), 
                                              all.names = TRUE),
                                envir = globalenv() )
    # load current packages in workers
    pkgs <- .packages()
    lapply( pkgs, function(pkg) 
     parallel::clusterCall(cl, library, package = pkg, 
       character.only = TRUE))
    doParallel::registerDoParallel(cl, cores = numCores)
  } else if( parallelType == "multicore" ) { 
    # multicore functionality on Unix-like systems
    cl <- parallel::makeCluster(numCores, type = "FORK")
    doParallel::registerDoParallel(cl, cores = numCores) 
    attr( parallel, "cluster") <- cl
  } else { 
    stop("Only 'snow' and 'multicore' clusters allowed!") 
  }
  return( parallel )
}

mptmem_stopParallel <- function( cluster, ... )
{ 
  # Stop parallel computing for GA package
  parallel::stopCluster(cluster)
  foreach::registerDoSEQ()
  invisible()
}