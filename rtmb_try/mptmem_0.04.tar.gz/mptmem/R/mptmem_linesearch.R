mptmem_linesearch <- function( parm = NULL, parm_list = NULL, parm_table = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, 
  method = NULL, type_mpt = NULL, type_sigma = NULL, raneff_list = NULL, 
  agh_list = NULL, qmc_pts = NULL, use_rcpp = NULL, output = NULL, incr = NULL, 
  ls_init_alpha = NULL, ls_tau = NULL, ls_tol = NULL, ls_iter_max = 10, 
  dev_old = NULL )
{
  #- everything for the line-search algorithm:
  ls_iter_no <- 0
  ls_alpha <- ls_init_alpha 
  iterate_line_search <- TRUE
  #- iterations
  while ( iterate_line_search ) {  
    #- make line search step
    ls_alpha <- ls_alpha * ls_tau
    incr <- incr * ls_alpha
    parm_new <- parm - incr
    #- compute new deviance-value
    dev_new <- mptmem_llfct( parm = parm_new, parm_list = parm_list, 
      parm_table = parm_table, catDat = catDat, perDat = perDat, 
      probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
      type_mpt = type_mpt, type_sigma = type_sigma, 
      raneff_list = raneff_list, agh_list = agh_list, 
      qmc_pts = qmc_pts, use_rcpp = use_rcpp, output = 0 )
    #- compare...
    if ( ls_iter_no > ls_iter_max ){ iterate_line_search <- FALSE }
    if ( dev_new <= dev_old ) { iterate_line_search <- FALSE }
    #- increase counter
    ls_iter_no <- ls_iter_no + 1
  }
  # if ( ls_iter_no > ls_iter_max ) { parm_new <- parm - 0.2 }
  #- output
  res <- list( parm_new = parm_new, dev_new = dev_new, incr = incr, 
    ls_iter_no = ls_iter_no, ls_alpha = ls_alpha )
  return( res )
}
