
mptmem_create_lists <- function( parm_table = NULL, include_fixed = NULL )
{
  #- make the matrices for parm_list
  mmRows <- attr( parm_table, "mmRows" )
  mmCols <- attr( parm_table, "mmCols" )
  mmNames <- names( mmRows )
  parm_list <- as.list( length( mmNames ) )
  for ( mm in 1:length( mmNames ) ) { 
    name_mm <- mmNames[ mm ]
    mat_mm <- matrix( 0, nrow = mmRows[[mm]], ncol = mmCols[[mm]] )
    parm_list[[mm]] <- mat_mm
    names( parm_list )[mm] <- name_mm
  }
  #- include fixed values:
  idx <- which( !is.na( parm_table$fixed ) )
  if ( include_fixed & length( idx ) != 0 ) {
    for ( ii in 1:length( idx ) ) {
      #- get row in parm_table
      nn <- parm_table[ idx[ii], ]
      #- get matrix
      mat <- nn$mat
      pos <- as.numeric( nn[ c("row","col") ]  )
      x_nn <- parm_list[[ mat ]]               
      x_nn[ pos[1] , pos[2] ] <- nn$fixed
      # SIGMA is symmetric!
      if ( mat == "SIGMA" ) { x_nn[ pos[2] , pos[1] ] <- nn$fixed }   
      parm_list[[ mat ]] <- x_nn       
    }
  }  
  return( parm_list )
}
