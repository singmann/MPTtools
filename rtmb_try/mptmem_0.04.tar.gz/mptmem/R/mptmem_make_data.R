
mptmem_make_data <- function( mpt_data = NULL, var_names = NULL, 
    cov_names = NULL, mptparm_names = NULL )
{
  #- some checks
  if ( !all( var_names %in% colnames( mpt_data ) ) ) {
    stop("Some category data is missing.")
  }
  if ( !all( cov_names %in% colnames( mpt_data ) ) ) {
    stop("Some category data is missing.")
  }
  #- get the data for the categories:
  catDat <- as.matrix( mpt_data[,var_names] )
  attr( catDat, "dimnames") <- NULL
  #- get the data for the person covariates:
  if ( length( cov_names ) != 0 ) {
    perDat <- as.matrix( mpt_data[,cov_names] )
    #perDat <- t( perDat )
    attr( perDat, "dimnames") <- NULL
  } else {
    perDat <- NULL
  }
  #- get number of persons:
  N <- dim( catDat )[1]
  data_list <- list( catDat = catDat, perDat = perDat, N = N )
  return( data_list )
}
