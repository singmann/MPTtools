
mptmem_raneffs_singleperson_agh <- function( tCatDat = NULL, tPerDat = NULL, raneffs = NULL, 
    parm_list = NULL, agh_list = NULL, probmatrix = NULL, catmatrix = NULL,
    type_mpt = NULL, SIGMA = NULL )
{
  #- get quadrature information
  tmp.pts <- agh_list[["tmp.pts"]]
  tmp.exp <- agh_list[["tmp.exp"]] # exp-transformed quadrature points
  tmp.wghexp <- agh_list[["tmp.wghexp"]] 
  #- get information on the nmber of dimensions of SIGMA
  Q <- dim( SIGMA )[1]
  #- estimate mode of theta and hessian matrix of theta
  MODE <- raneffs[["MODE"]]
  CHOL <- raneffs[["CHOL"]]
  DET  <- raneffs[["DET"]] 
  #- compute transformed quadrature points
  tmp.pts <- tmp.pts%*%CHOL
  tmp.pts <- sweep( tmp.pts, 2, MODE, "+")   
  #- compute normal density values of quadratute points given Gom
  tmp.den <- mvtnorm::dmvnorm( tmp.pts, tPerDat, SIGMA )
  #- compute conditional likelihood values for the adapted quadrature points
  tmp.fun <- apply( tmp.pts, 1, mpt_mem_llfct_data, tCatDat = tCatDat, probmatrix = probmatrix, 
    catmatrix = catmatrix, type_mpt = type_mpt ) 
  #- compute the produt of values, density and weights
  out <- apply( cbind( tmp.wghexp, tmp.den, tmp.fun ), 1, prod ) 
  #- final computations:
  sqrtDET <- sqrt( DET )
  int <- (2*pi)^(Q/2)*sqrtDET*( out %*% tmp.pts )
  hi <- as.numeric( (2*pi)^(Q/2)*sqrtDET*sum( out ) )
  #- raneff for omega:
  reff <- int/hi
  #- combine the random effects:
  return( reff )
}

mptmem_raneffs <- function( object = NULL, center = TRUE )
{
  #- collect all relevant args:
  parm_list <- object$parm_list
  raneff_list <- object$raneff_list
  agh_list <- object$agh_list
  qmc_pts <- object$qmc_pts
  catDat <- object$catDat
  perDat <- object$perDat
  probmatrix <- object$probmatrix
  catmatrix <- object$catmatrix
  method <- object$method
  type_mpt <-  object$type_mpt
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  SIGMA <- parm_list[["SIGMA"]]
  MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MU + GAM%*%perDat
  } else { TOperDat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE ) }
  #- let's go:
  tmp <- vector( "list", T )
  for ( tt in 1:T ) {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "AGH" ) { 
      out <- mptmem_raneffs_singleperson_agh( tCatDat = tCatDat, tPerDat = tPerDat, 
        raneffs = raneffs, agh_list = agh_list, probmatrix = probmatrix, catmatrix = catmatrix, 
        type_mpt = type_mpt, SIGMA = SIGMA )
    } 
    if ( method == "QMC" ) {
      out <- mptmem_llfct_qmc( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        qmc_pts = qmc_pts, probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA )    
    } 
    if ( method == "Laplace" ) {
      stop("We do not support the estimation of random effects with Laplace.")
    }
    tmp[[ tt ]] <- c( tt, out )    
  } 
  #- combine all elements in tmp to obtain EAPs:
  means <- do.call("rbind", tmp )
  #- combine all relevant elements in raneffs to obtain modes:
  modes <- do.call("rbind", lapply( raneff_list, function(x) { x$MODE } ) )
  modes <- cbind( means[,1], modes )
  #- do we have to center the variables:    
  if( center ) {
    means[,-1] <- apply( means[,-1], 2, function(x) x - mean(x) ) 
    modes[,-1] <- apply( modes[,-1], 2, function(x) x - mean(x) )
  }
  # outcome:
  res <- list( means = means, modes = modes )
  return( res )
}