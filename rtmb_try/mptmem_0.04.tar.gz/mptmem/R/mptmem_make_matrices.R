
mptmem_make_matrices <- function( per_table = per_table, mpt_table = mpt_table )
{
  #- make the matrices for mpt part
  ordering <- unique( mpt_table$tree )
  mpt_table$num_tree <- as.numeric( factor( mpt_table$tree, levels = ordering ) )
  ordering <- unique( mpt_table$cat )
  mpt_table$num_cat <- as.numeric( factor( mpt_table$cat, levels = ordering ) )
  probmatrix <- as.matrix( mpt_table[,c("num_tree","num_cat","branch","parm","parminv")])
  attr( probmatrix, "dimnames") <- NULL
  catmatrix <- as.matrix( aggregate( mpt_table[,c("branch")], by = list( mpt_table$num_tree, 
    mpt_table$num_cat), length ) )
  catmatrix[,3] <- catmatrix[,3]/length( unique( mpt_table$pathcoef ) ) 
  attr( catmatrix, "dimnames") <- NULL
  #- output
  res <- list( probmatrix = probmatrix, catmatrix = catmatrix )
  return( res )
}
