
## -- function to include parameter values:

mptmem_include_freeparms <- function( parm = NULL, parm_list = NULL, parm_table = NULL ) 
{       
  NP <- max( parm_table$index )
  NOP <- nrow( parm_table )         
  for (nn in 1:NOP){
    free_nn <- parm_table[nn,]
    mat <- free_nn$mat
    pos <- as.numeric( free_nn[ c("row","col") ]  )
    index_nn <- free_nn$index
    x_nn <- parm_list[[ mat ]]               
    x_nn[ pos[1] , pos[2] ] <- parm[ free_nn$index ]
    # SIGMA is symmetric!
    if ( mat == "SIGMA" ) { x_nn[ pos[2] , pos[1] ] <- parm[ free_nn$index ] }   
    parm_list[[ mat ]] <- x_nn                               
  }
  return( parm_list )
}

## -- function to get quadrature points:

mptmem_getquadpoints <- function( nGH = NULL, dimension = NULL) 
{
  # make a grid
  idx <- as.matrix(expand.grid(rep(list(1:nGH),dimension)))
  # get the quadrature points
  tmp.val <- fastGHQuad::gaussHermiteData(nGH)
  # save the weights
  tmp.wgh <- matrix(tmp.val$w[idx],nrow(idx),dimension)
  # save the points
  tmp.pts <- matrix(tmp.val$x[idx],nrow(idx),dimension)  
  # transform and exp the points for agh quadrature
  tmp.wgh <- (1/sqrt(pi))*tmp.wgh
  tmp.pts <- sqrt(2)*tmp.pts
  tmp.exp <- as.matrix(exp(0.5*rowSums(tmp.pts * tmp.pts)))
  tmp.wghexp <- apply(cbind(tmp.wgh,tmp.exp),1,prod)
  # output
  gh_list <- list(tmp.wgh = tmp.wgh, tmp.pts = tmp.pts, tmp.exp = tmp.exp, tmp.wghexp = tmp.wghexp )
  return( gh_list )
}

## -- function to get qmc points:

# mptmem_getqmcpoints <- function( n = NULL, dimension = NULL, type = "Halton" ) 
# {
#   #- make a null object:
#   tmp_pts <- NULL
#   #- generate points:
#   if ( type == "Halton") {
#     tmp_pts <- fOptions::runif.halton( n = n, dimension = dimension ) 
#   } else if ( type == "Sobol") {
#     tmp_pts <- fOptions::runif.sobol( n = n, dimension = dimension ) 
#   } else {
#     stop("Method to obtain QMC points not available.")
#   }
#   #- use the normal transform:
#   tmp_pts <- stats::qnorm( tmp_pts, mean = 0, sd = 1 )
#   #- output:
#   return( tmp_pts )
# }

mptmem_getqmcpoints <- function( n = NULL, 
  dimension = NULL, type = "Halton" ) 
{
  #- make a null object:
  tmp_pts <- NULL
  #- generate points:
  if ( type == "Halton" ) {
    tmp_pts <- randtoolbox::halton( n = n, dim = dimension ) 
  } else if ( type == "Sobol" ) {
    tmp_pts <- randtoolbox::sobol( n = n, dim = dimension ) 
  } else {
    stop("Method to obtain QMC points not available.")
  }
  #- use the normal transform:
  tmp_pts <- as.matrix( stats::qnorm( tmp_pts, mean = 0, sd = 1 ) )
  #- output:
  return( tmp_pts )
}

# mptmem_nearPD <- function( mat = NULL )
# {
#   p <- dim(mat)[1]
#   e <- eigen( mat, sym = TRUE )
#   new_values <- e$values * (e$values > 0)
#   vec <- e$vectors
#   # compute nearPD matrix
#   T <- sqrt( diag( as.vector( 1/(vec^2 %*% new_values ) ), p, p ) )
#   B <- T %*% vec %*% diag( as.vector( sqrt( new_values ) ), p, p )
#   out <- B %*% t(B)
#   return( out )
# }

# mptmem_utils_check_vcov <- function( hessian = NULL )
# {
#   #- ...
#   warning_vcov <- 0
#   #- compute vcov:
#   vcov <- tryCatch( MASS::ginv( 0.5*hessian ), error = function(e) { NULL } )
#   if ( is.null( vcov ) ) {
#     warning_vcov <- 1 
#   } else {
#     ev <- eigen( vcov )$values
#     if ( any( is.complex( ev ) ) ) {
#       ev <- Re(ev) 
#     } 
#     if ( any( ev < 0 ) ) {
#       #vcov <- mptmem_nearPD( vcov )
#       vcov <- Matrix::nearPD( hessian )
#       warning_vcov <- 2
#     }
#   }
#   res <- list( warning_vcov = warning_vcov, vcov = vcov )
#   return( res )
# }

mptmem_utils_compute_ses <- function( hessian = NULL )
{
  #- compute vcov:
  warning_vcov <- 0
  vcov <- tryCatch( solve( 0.5*hessian ), error = function(e) { NULL } )
  if ( is.null( vcov ) ) {
    warning_vcov <- 1 
  } else {
    se <- suppressWarnings( sqrt( diag( vcov ) ) )
    if ( any( is.na( se ) ) ) {
      vcov <- tryCatch( Matrix::nearPD( vcov ), error = function(e) { NULL } )
      if ( is.null( vcov ) ) {
        warning_vcov <- 1 
      } else {
        vcov <- as.matrix( vcov$mat )
        se   <- suppressWarnings( sqrt( diag( vcov ) ) )
        warning_vcov <- 2
      }
    } 
  }
  res <- list( warning_vcov = warning_vcov, vcov = vcov, se = se )
  return( res )
 }

# mptmem_utils_check_hessian <- function( hessian = NULL )
# {
#   ev <- eigen( hessian )$values
#   if ( any( is.complex( ev ) ) ) {
#     ev <- Re(ev) 
#   } 
#   if ( any( ev < 0 ) ) {
#     #hessian <- mptmem_nearPD( hessian )
#     hessian <- Matrix::nearPD( hessian )
#   }
#   return( hessian )
# }