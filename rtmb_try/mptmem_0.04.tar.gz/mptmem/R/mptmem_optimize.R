
mptmem_optimize <- function( parm_table = NULL, parm_list = NULL, catDat = NULL, 
    perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = NULL, 
    type_mpt = NULL, type_sigma = NULL, use_rcpp = NULL, control = NULL )
{
	#- collect arguments for internal optimizer:
  optimizer <- control[["opt_method"]]
  method_control_list <- control[["method_control_list"]]
  #- make quadrature or qmc points:
  noDim <- dim( parm_list[["SIGMA"]] )[1]
  if ( method == "AGH" ) {
    agh_list <- mptmem_getquadpoints( nGH = control$nGH, dimension = noDim )
    qmc_pts <- NULL
  } else if ( method == "QMC" ) {
    agh_list <- NULL
    qmc_pts <- mptmem_getqmcpoints( n = control$qmcSample, dimension = noDim, 
      type = control$qmcType ) 
  } else { agh_list <- qmc_pts <- NULL }
  #- collect arguments for external optimizing:
  maxit_out   <- control$maxit_out
  x_tol_out   <- control$x_tol_out
  fx_tol_out  <- control$fx_tol_out
  verbose_out <- control$verbose_out
  #- some final things:
  parm_new <- parm_table[ attr( parm_table, "parm_idx" ), "starts"]
  idx      <- which( ! is.na( parm_table$index ) )
  parm_table_small <- parm_table[idx,]
  ub <- parm_table[ attr( parm_table, "parm_idx" ), "up"]
  lb <- parm_table[ attr( parm_table, "parm_idx" ), "low"]
  #- things for the algorithm: 
  diterate <- TRUE
  diter    <- 0
  dev_new  <- 0
  hessian  <- NULL
  warning_raneff <- 0
  #- start the optimizer:
  while ( diterate ) {
    #- old parm_vector:	 
    parm_old <- parm_new
    dev_old <- dev_new            
    #- Step 1: get random effect estimates:
    raneff_list <- suppressWarnings( tryCatch( { 
      mptmem_getmodes( parm = parm_old, parm_table = parm_table_small, 
      parm_list = parm_list, catDat = catDat, perDat = perDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt, type_sigma = type_sigma ) },
      error = function(e) { NULL },
      warning = function(w) { NULL } ) )
    #- error handling:
    if ( is.null( raneff_list ) ) {
      parm_new <- parm_old
      dev_new  <- dev_old
      warning_raneff <- 1
      break
    }
    #- Step 2: within optimizing:
    if ( optimizer == "nlminb" ) {
      tmp_res <- stats::nlminb( start = parm_old, objective = mptmem_llfct, 
        gradient = mptmem_gradient, control = method_control_list, 
        lower = lb, upper = ub, parm_list = parm_list, 
        parm_table = parm_table_small, catDat = catDat, perDat = perDat, probmatrix = probmatrix, 
        catmatrix = catmatrix, method = method, type_mpt = type_mpt, , type_sigma = type_sigma,
        raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
        use_rcpp = use_rcpp, output = 0 )
      #- get updated values:
      parm_new <- tmp_res$par
      dev_new  <- tmp_res$objective
    } 
    if ( optimizer == "nloptr" ) {
      if ( method_control_list$algorithm %in% c("NLOPT_LD_LBFGS","NLOPT_LD_CCSAQ") ) {
        tmp_res <- nloptr::nloptr( x0 = parm_old, eval_f = mptmem_gradient, 
          lb = lb, ub = ub, opts = method_control_list, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, 
          raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
          use_rcpp = use_rcpp, output = 1 )
      } else if ( method_control_list$algorithm %in% c("NLOPT_LN_BOBYQA","NLOPT_LN_SBPLX","NLOPT_LN_PRAXIS") ) {
        tmp_res <- nloptr::nloptr( x0 = parm_old, eval_f = mptmem_llfct, 
          lb = lb, ub = ub, opts = method_control_list, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, 
          raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
          use_rcpp = use_rcpp, output = 0 )
      }
      parm_new <- tmp_res$solution
      dev_new  <- tmp_res$objective   
    } 
    if ( optimizer == "newton_raphson") {
      convcrit_inn <- method_control_list$convcrit_nr
      maxit_inn    <- method_control_list$maxit_nr
      diterate_inn <- TRUE
      parm_new_inn <- parm_old
      # start newton_raphson:
      while ( diterate_inn ) {
        #- make output
        if ( method_control_list$verbose_inn ) {
          xx_inn <- as.character()
          tb_inn <- c( round( parm_new_inn, 4 ) )
          for (j in 1:length(tb_inn)) { xx_inn <- paste0(xx_inn, sprintf(" %g", tb_inn[j])) }
            h1 <- paste0("parms = ", xx_inn )
          cat(h1, "\n")
          utils::flush.console()
        }
        #- get parm
        parm_old_inn <- parm_new_inn
        #- compute hessian, gradient and ll_old
        tmp <- mptmem_hessian( parm = parm_old_inn, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
          agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp )
        dev_old_inn <- tmp[["llfct"]]
        grad        <- tmp[["gradient"]]
        hessian     <- tmp[["hessian"]]  
        incr <- solve( hessian, grad )
        #- line search:
        lsearch <- mptmem_linesearch( parm = parm_old_inn, parm_list = parm_list, 
          parm_table = parm_table_small, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
          agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp, output = 0, 
          incr = incr, ls_init_alpha = 2, ls_tau = 0.5, ls_tol = 0, ls_iter_max = 10, 
          dev_old = dev_old_inn )
        parm_new_inn <- lsearch[["parm_new"]]
        #- check convergence:
        if ( max( abs( parm_new_inn - parm_old_inn ) ) < convcrit_inn | diter > maxit_inn ) {  
          diterate_inn <- FALSE
        } 
      }
      parm_new <- parm_new_inn
      dev_new <- lsearch[["dev_new"]]
    }
    # if ( optimizer == "sgd") {
    #   tmp_res <- snoptim::snoptim( start = parm_old, fn = mptmem_llfct, 
    #     gr = mptmem_gradient, 
    #     control = method_control_list[names(method_control_list)!="algorithm"], 
    #     lb = lb, ub = ub,
    #     type = method_control_list$algorithm,
    #     parm_list = parm_list, parm_table = parm_table_small, catDat = catDat, 
    #     perDat = perDat, probmatrix = probmatrix, catmatrix = catmatrix, 
    #     method = method, type_mpt = type_mpt, , type_sigma = type_sigma,
    #     raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
    #     use_rcpp = use_rcpp, output = 0 )
    #   parm_new <- tmp_res$solution
    #   dev_new  <- tmp_res$fval  
    # }
    #- set diter:     
    diter <- diter + 1
    #- check convergence:
    dev_crit  <- abs( dev_new - dev_old )/dev_new
    parm_crit <- max( abs( parm_new - parm_old ) )
    if ( parm_crit < x_tol_out | dev_crit < fx_tol_out | diter > maxit_out ) { 
      diterate <- FALSE
    } 
    #- make output
    if ( verbose_out ) {
      xx <- as.character()
      tb <- c( round( parm_new, 4 ) )
      for (j in 1:length(tb)) { xx <- paste0(xx, sprintf(" %g", tb[j])) }
      h1 <- paste0("Deviance = " , round( dev_new , 3 ), 
                   " | parms = ", xx )
			cat(h1, "\n")
			utils::flush.console()
    }
  }
  #- output:
  if ( !diterate ) {
    conv <- 0
    mstats <- mptmem_modelstats( parm = parm_new, parm_list = parm_list, 
      parm_table = parm_table_small, catDat = catDat, perDat = perDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, method = method, type_mpt = type_mpt, type_sigma = type_sigma, 
      raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
      use_rcpp = use_rcpp, dev = dev_new, hessian = hessian, 
      with_ses = control$with_ses, est_hessian = control$est_hessian )
    vcov         <- mstats$vcov 
    logLik       <- mstats$logLik
    aic          <- mstats$aic
    bic          <- mstats$bic
    Deviance     <- mstats$Deviance
    parm_table   <- mstats$parm_table
    parm_list    <- mstats$parm_list
    warning_vcov <- mstats$warning_vcov
  } else { 
    conv <- 1; warning_vcov <- 0;
    parm_table <- parm_table_small;
    parm_table$est <- parm_table$se <- parm_table$z <- NA;
    vcov <- logLik <- se <- aic <- bic <- Deviance <- NA;
  }
  res <- list( coef = parm_new, vcov = vcov, logLik = logLik, aic = aic, 
    bic = bic, Deviance = Deviance, conv = conv, warning_vcov = warning_vcov, 
    warning_raneff= warning_raneff, parm_table = parm_table, parm_list = parm_list, 
    agh_list = agh_list, qmc_pts = qmc_pts, raneff_list = raneff_list )
  return( res )
}