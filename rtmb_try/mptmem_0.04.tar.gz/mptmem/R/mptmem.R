
mptmem <- function( model.syntax = NULL, data = NULL, control = mptmem_control(), 
  method = "AGH", type_mpt = "logit", type_sigma = "UN", use_rcpp = TRUE, 
  use_parallel = FALSE )
{
  #---------------------------------------------------------------------------
  #- control parameters and then checks, checks, checks...
  missCtrl <- missing( control )
  if ( !missCtrl && !inherits( control, "mptmem_control" ) ) {
    if(!is.list(control)) { stop("'control' has to be a list.") }
      control <- do.call( mptmem_control, control )
  }
  if ( !( method %in% c("AGH","QMC","Laplace")) ) {
    stop("The method you specified is not available.") }
  if ( !( type_mpt %in% c("logit", "probit") ) ) {
    stop("Either 'logit' or 'probit' is available.") }
  if ( !( type_sigma %in% c("UN", "CD", "FA") ) ) {
    stop("Only 'UN', 'CD' or 'FA' is available.") }
  if ( method == "Laplace" & control$opt_method == "newton_raphson" )  {
    stop("Laplace is not available for Newton-Raphson.") }
  if ( method == "Laplace" & control$est_hessian )  {
    stop("Laplace is not available for Hessian estimation.") }
  if ( control$opt_method == "newton_raphson" & control$with_ses )  {
    control$est_hessian = FALSE }  
  
  #---------------------------------------------------------------------------
  
  #---------------------------------------------------------------------------
  #- use model syntax to generate parameter tables
  model_tables <- mptmem_get_tables( model.syntax = model.syntax )
  mpt_table <- model_tables[["mpt.table_mat"]]
  per_table <- model_tables[["per.table_mat"]]
  var_names <- attr( per_table, "var_names")
  cov_names <- attr( per_table, "cov_names")
  #---------------------------------------------------------------------------

  #---------------------------------------------------------------------------
  #- make prob- and catmatrix
  model_mats <- mptmem_make_matrices( per_table = per_table, mpt_table = mpt_table )
  probmatrix <- model_mats[["probmatrix"]]
  catmatrix  <- model_mats[["catmatrix"]]
  #---------------------------------------------------------------------------

  #---------------------------------------------------------------------------
  #- get data
  data_list <- mptmem_make_data( mpt_data = data, var_names = var_names, 
    cov_names = cov_names )
  catDat <- data_list[["catDat"]]
  perDat <- data_list[["perDat"]]
  #---------------------------------------------------------------------------

  #---------------------------------------------------------------------------
  #- add start_values and bounds, generate parm_table
  parm_table <- mptmem_optimize_addinformation( per_table = per_table, probmatrix = probmatrix, 
    catmatrix = catmatrix, catDat = catDat, perDat = perDat, type_mpt = type_mpt, 
    type_sigma = type_sigma, control = control )

  #- create lists of model parameters ( with fixed parms included )
  parm_list <- mptmem_create_lists( parm_table = parm_table, include_fixed = TRUE  )
  
  #- another check for equality constraints and newton-raphson:
  if ( control$opt_method == "newton_raphson" & any( table( parm_table$index, useNA = c("no") ) > 1 ) ) {
    stop("Newton-Raphson is not available for models with equality constraints.") }

  #- another check for equality constraints and newton-raphson:
  if ( type_sigma == "FA" & any( table( parm_table$index, useNA = c("no") ) > 1 ) ) {
    stop("Factor analysis is not available for models with equality constraints.") }   
  #---------------------------------------------------------------------------

  #---------------------------------------------------------------------------
  #- parallel fitting:
  if( use_parallel ) { 
    parallel <- mptmem_startParallel( parallel = use_parallel, control = control )
    stopCluster <- TRUE 
  } else { 
    parallel <- stopCluster <- FALSE  
  }
  on.exit( if( parallel & stopCluster ) 
    mptmem_stopParallel( attr(parallel, "cluster") ) )

  if ( use_parallel ) {
    res <- mptmem_optimize_parallel( parm_table = parm_table, 
      parm_list = parm_list, catDat = catDat, perDat = perDat, 
      probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
      type_mpt = type_mpt, type_sigma = type_sigma, use_rcpp = use_rcpp, 
      control = control )
  } else {
    res <- mptmem_optimize( parm_table = parm_table, parm_list = parm_list, catDat = catDat, 
      perDat = perDat, probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
      type_mpt = type_mpt, type_sigma = type_sigma, use_rcpp = use_rcpp, 
      control = control )
  }
  #---------------------------------------------------------------------------
  
  #---------------------------------------------------------------------------
  #- some final checks, warnings etc.
  eival <- eigen( res[["parm_list"]]$SIGMA )$values
  if( length( eival[ eival <= 0] ) > 0 ) {
    warning("Variance-covariance matrix of random effects is not positive definite.")
  }
  if ( res$conv == 1 ) {
    warning("The algorithm did not converge.")
  }
  if ( res$warning_raneff != 0 ) {
      warning("Problems when estimating modes.")
  }
  if( control$print_warning_vcov ) {
    if ( res$warning_vcov != 0 ) {
      if ( res$warning_vcov == 1 ) {
        warning("Hessian is not invertible. The covariance matrix of the 
                 estimates could not be computed.")
      } else if ( res$warning_vcov == 2 ) {
        warning("The covariance matrix of the estimates is not positive 
                 definite. The standard errors were corrected but may not 
                 be trustworthy.")
      }
    }
  }  
  #---------------------------------------------------------------------------

  #- output:
  out <- list( coef = res$coef, vcov = res$vcov, logLik = res$logLik, Deviance = res$Deviance,
    aic = res$aic, bic = res$bic, parm_table = res$parm_table, parm_list = res$parm_list, 
    warning_cov = res$warning_vcov, raneff_list = res$raneff_list, agh_list = res$agh_list, qmc_pts = res$qmc_pts,
    probmatrix = probmatrix, catmatrix = catmatrix, data_list = data_list, mpt_table = mpt_table, 
    per_table = per_table, method = method, type_mpt = type_mpt, type_sigma = type_sigma,
    control = control )
  class( out ) <- 'mptmem'
  return( out )
}
