
mptmem_single_level_prepare <- function( parm = NULL, type_mpt = NULL )
{
	#- initialize: 
	prep_parm <- parm
  #- compute scaled parm:
  if ( type_mpt == "logit" ) {
    prep_parm <- 1/( 1 + exp(-1*parm) )
  } else if ( type_mpt == "probit" ) {
    prep_parm <- pnorm( parm, 0 , 1 )
  } 
  #- output
  return( prep_parm ) 
}

mptmem_single_level_prepare_gradient <- function( parm = NULL, type_mpt = NULL )
{
  #- initialize: 
  prep_parm <- parm
  #- compute scaled parm:
  if ( type_mpt == "logit" ) {
    #tmp <- 1/( 1 + exp(-1*parm) )
    prep_parm <- exp( parm)/(( 1 + exp(parm) )^2)#tmp*(1 - tmp )
  } else if ( type_mpt == "probit" ) {
    prep_parm <- dnorm( parm, 0 , 1 )
  } 
  #- output
  return( prep_parm ) 
}

mptmem_single_level_catprob_pureR <- function( parm = NULL, catmatrix = NULL, 
    probmatrix = NULL ) 
{
    #- extract no. of parms:
    S <- length( parm )
    #- extract no. of independent sub categories:
    K <- dim( catmatrix )[1]
    #- vector for over probabilities:
    P_Ck <- rep( 0, K )
    #- iterate over K:
    idx1 <- 1
    idx2 <- S
    for ( k in 1:K ) {
    	#- get no. of subtrees in subcategory k:
    	Ikj <- catmatrix[ k, 3 ]
    	#- loop through subcategories:
    	for ( i in 1:Ikj ) {
          	#- get branch matrix:
          	#AB <- probmatrix[ probmatrix[,2] == k & probmatrix[,3] == i,]
           	AB <- probmatrix[idx1:idx2,]
            #- get single path prob:
           	tmp1 <- tmp2 <- 1
           	for ( s in 1:S ) {
               	if ( AB[s,4] != 0 ) {
                   	tmp1 <- tmp1*parm[s]^AB[s,4] }
               	if ( AB[s,5] != 0 ) {
                   	tmp2 <- tmp2*(1-parm[s])^AB[s,5] }
           	}
            idx1 <- idx1 + S
            idx2 <- idx2 + S
            P_Ck[k] <- P_Ck[k] + tmp1*tmp2
    	} # Ikj
    } # K
    return( P_Ck )
}

mptmem_single_level_catprob_gradient_pureR <- function( parm = NULL, catmatrix = NULL, 
    probmatrix = NULL, parmDer = NULL )
{
  #- extract no. of parms:
  S <- length( parm )
  #- extract no. of independent sub categories:
  K <- dim( catmatrix )[1]
  #- vector for over probabilities:
  P_Ck <- rep( 0, K )
  derP_Ck <- matrix( 0, nrow = K, ncol = S )
  #- iterate over K:
  idx1 <- 1
  idx2 <- S
  derivative_lldata <- 0
  for ( k in 1:K ) {
    #- get no. of subtrees in subcategory k:
    Ikj <- catmatrix[ k, 3 ]
    #- loop through subcategories:
    for ( i in 1:Ikj ) {
      #- get branch matrix:
      AB <- probmatrix[idx1:idx2,]
      #- get single path prob:
      tmp1 <- tmp2 <- 1
      for ( s in 1:S ) {
        if ( AB[s,4] != 0 ) {
          tmp1 <- tmp1*parm[s]^AB[s,4] }
          if ( AB[s,5] != 0 ) {
            tmp2 <- tmp2*(1-parm[s])^AB[s,5] }
          }
          idx1 <- idx1 + S
          idx2 <- idx2 + S
          P_Ck[k] <- P_Ck[k] + tmp1*tmp2
          derP_Ck[k,] <- derP_Ck[k,] + tmp1*tmp2*( AB[,4]/parm - AB[,5]/(1-parm) )*parmDer
    } # Ikj
    derP_Ck[k,] <- derP_Ck[k,]/P_Ck[k]
  } # K
  return( derP_Ck )
}

#- function to compute log-Likelihood for a standard mpt

mptmem_single_level_llfct <- function( parm = NULL, catDat = NULL, 
	probmatrix = NULL, catmatrix = NULL, type_mpt = NULL )
{
  #- prepare the parm-vector:
  parm0 <- mptmem_single_level_prepare( parm = parm, type_mpt = type_mpt )
  #- compute probabilities of the categories:
  P_Ck <- mptmem_single_level_catprob_pureR( parm = parm0, probmatrix = probmatrix, 
    catmatrix = catmatrix )
  #- compute likelihood:
  llfct <- sum( catDat*log(P_Ck) ) 
  #- return outcome
  return( -1*llfct )
}

#- function to compute gradient for a standard mpt

mptmem_single_level_gradient <- function( parm = NULL, catDat = NULL, 
  probmatrix = NULL, catmatrix = NULL, type_mpt = NULL )
{
  #- prepare the parm-vector:
  parm0 <- mptmem_single_level_prepare( parm = parm, type_mpt = type_mpt )
  #- prepare the derivative parm-vector:
  parmDer <- mptmem_single_level_prepare_gradient( parm = parm, type_mpt = type_mpt )
  #- compute gradients:
  derP_Ck <- mptmem_single_level_catprob_gradient_pureR( parm = parm0, 
    catmatrix = catmatrix, probmatrix = probmatrix, parmDer = parmDer )
  llgrad <- colSums( catDat*derP_Ck )
  #- return outcome
  return( -1*llgrad )
}

mptmem_single_level_getCatprobs <- function( parm = NULL, catDat = NULL, 
  probmatrix = NULL, catmatrix = NULL, type_mpt = NULL )
{
  #- prepare the parm-vector:
  parm0 <- mptmem_single_level_prepare( parm = parm, type_mpt = type_mpt )
  #- compute probabilities of the categories:
  P_Ck <- mptmem_single_level_catprob_pureR( parm = parm0, probmatrix = probmatrix, 
    catmatrix = catmatrix )
  #- return outcome
  return( P_Ck )
}

#- function to get the parameter estimates for a standard mpt

mptmem_single_level_fit <- function( start = NULL, catDat = NULL, probmatrix = NULL, 
	catmatrix = NULL, type_mpt = NULL, control = NULL, modeltest = FALSE )
{
	#- collect control arguments:
	method_control_list <- list( trace = control$verbose_inn, iter.max = control$maxit_inn, 
    abs.tol = control$abs_tol_inn, rel.tol = control$rel_tol_inn, step.min = control$step_min_inn, 
    x.tol = control$x_tol_inn )
	#- check whether data is aggregrated across persons:
	if ( dim( catDat )[1] != 1 ) {
		catDat <- colSums( catDat)
	}
  #- estimate parm 
	fit <- stats::nlminb( start = start, objective = mptmem_single_level_llfct, catDat = catDat, 
		probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt )
  parm <- fit$par
  llfct <- fit$objective
  tf_parm <- mptmem_single_level_prepare( parm = parm, type_mpt = type_mpt )
  res <- list( parm = parm, llfct = llfct, tf_parm = tf_parm )
  # if ( !model_test ) {
		# pcat <- mpt_mem_single_level_catprob_pureR( parm = tf_parm, probmatrix = probmatrix, 
  #   	catmatrix = catmatrix )
  #   catmatrix <- cbind( catmatrix, as.vector( catDat ), as.vector( pcat ) )
  #   trees <- unique( catmatrix[,1] )
  #   nobs <- 0
  #   for ( ii in 1:length( trees ) ) {
  #    	idx <- which( catmatrix[,1] == trees[ii] )
  #   #	cme <- sum( catmatrix[idx,4] )
  #   #	catmatrix[,5] <- cme*catmatrix[,5]
  #   	nobs <- nobs + max( catmatrix[,2] ) - 1
  #   }
  #   res$fitted <- catmatrix[,4]*catmatrix[,5] 
  # 	res$G2 <- 2 * sum( catDat * log( catDat/ res$fitted ), na.rm = TRUE )
  # 	res$df <- nobs - length( parm )
 	# }
 	#- output
	return( res )
}