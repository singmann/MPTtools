
mptmem_get_tables <- function( model.syntax = NULL )
{
  #- Prepare the model syntax for parsing:
  model <- mptmem_prepare_parsing( model.syntax = model.syntax )
  #- Split the model into mpt- and person-part:
  models  <- mptmem_parsing_split( model = model )
  model.mpt <- models[[1]]
  model.per <- models[[2]]
  #- Make a list with parms etc. as specified by the user:
  mpt.list <- mptmem_parsing_list_mpt( model = model.mpt )
  per.list <- mptmem_parsing_list_person( model = model.per )
  #- We construct two tables that each contain user-specified parameters  
  #  and default-parameters
  mpt.table <- mptmem_partable_addelements_mpt( mpt.list = mpt.list )
  mpt.parms <- unique( mpt.table$pathcoef )
  per.table <- mptmem_partable_person( per.list = per.list, mpt.parms = mpt.parms )
  #- Now, we construct the final table, that contains the names of the matrices
  #  and the position of the to-be estimated parameters
  mpt.table_mat <- mptmem_partable_to_matrix_mpt( mpt.table = mpt.table ) 
  per.table_mat <- mptmem_partable_to_matrix_person( per.table = per.table, 
    mpt.parms = mpt.parms ) 
  #- We add the parameter and variable names to the respective table:
  par_names <- c( mpt.parms, unique( per.table_mat$mat ) )
  attr( per.table_mat, "par_names" ) <- par_names
  var_names <- unique( mpt.table_mat$cat )
  attr( per.table_mat, "var_names") <- var_names
  idx <- which( per.table_mat$op == "~" )
  cov_names <- unique( per.table_mat$rhs[idx] )
  attr( per.table_mat, "cov_names") <- cov_names
  #- that's it:  
  rownames( mpt.table_mat ) <- NULL
  rownames( per.table_mat ) <- NULL
  res <- list( per.table_mat = per.table_mat, mpt.table_mat = mpt.table_mat )
  return( res )
}