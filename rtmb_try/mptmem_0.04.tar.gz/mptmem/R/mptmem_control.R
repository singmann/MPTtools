
mptmem_control <- function( 
	nGH = 5, # number of points?
	qmcSample = 1000, # number of qmc-points
	qmcType = "Halton",
	delta_parallel = 1, 
	maxit_out = 20,
	x_tol_out = 10e-5,
  fx_tol_out = 1e-10,
	verbose_out = TRUE,	
	verbose_inn = FALSE,
  opt_method = "nloptr",
  nloptr_algorithm = "NLOPT_LD_LBFGS",
  gd_algorithm = "adam",
  control_nlminb = NULL,
  control_nloptr = NULL,
  control_snoptim = NULL,
  maxit_nr = 100L,
  convcrit_nr = 1e-4,
  with_ses = TRUE,
  est_hessian = TRUE,
  print_warning_vcov = FALSE ) 
{
  #- make method_control lists:  
  if ( opt_method == "nlminb" ) {
    #- make default list:
    default_list <- list( 
      iter.max = 500L,
      abs.tol = (.Machine$double.eps*10), 
      rel.tol = 1e-9,
      step.min = 2.2e-10, 
      x.tol = 1.5e-8,
      trace = 0 )
    #- check verbose_inn:
    if ( verbose_inn ) { default_list$trace = 1 }
    #- add to final list:
    method_control_list <- c( control_nlminb, 
      default_list[ !( names( default_list ) %in% names( control_nlminb ) ) ] )
  }
  if ( opt_method == "nloptr" ) {
    #- check algorithm:
    if ( !( nloptr_algorithm %in% c(
      "NLOPT_LD_LBFGS",
      "NLOPT_LD_CCSAQ",
      "NLOPT_LN_BOBYQA", 
      "NLOPT_LN_SBPLX",
      "NLOPT_LN_PRAXIS") ) ) {
        stop("Specified nloptr algorithm is not available.") 
    }
    #- make default list:
    default_list <- list( 
      algorithm = nloptr_algorithm,
      maxeval = 500L,
      ftol_abs = (.Machine$double.eps*10), 
      ftol_rel = 1e-9,
      xtol_abs = 1.5e-8,
      print_level = "0" )
    #- check verbose_inn:
    if ( verbose_inn ) { default_list$print_level = "3" }
    #- add to final list:
    method_control_list <- c( control_nloptr, 
      default_list[ !( names( default_list ) %in% names( control_nloptr ) ) ] )
  }
  if ( opt_method == "newton_raphson" ) {
    #- make default list:
    method_control_list <- list( 
      convcrit_nr = convcrit_nr,
      maxit_nr = maxit_nr,
      verbose_inn = verbose_inn )
  }
  if ( opt_method == "gd" ) {
    #- check algorithm:
    if ( !( gd_algorithm %in% c(
      "adam",
      "nadam",
      "adagrad", 
      "rmsprop",
      "momentum",
      "nesterov") ) ) {
        stop("Specified snoptim algorithm is not available.") 
    }
    #- make default list:
    default_list <- list( 
      algorithm = gd_algorithm,
      iterlim = 500L,
      learningRate = 0.01,
      abs.tol = (.Machine$double.eps*10), 
      rel.tol = 1e-9,
      x.tol = 1.5e-8,
      printLevel = 0 )
    #- check verbose_inn:
    if ( verbose_inn ) { default_list$printLevel = 1 }
    #- add to final list:
    method_control_list <- c( control_snoptim, 
      default_list[ !( names( default_list ) %in% names( control_snoptim ) ) ] )
  }
  #- make args:
	args <- list( 
		nGH = nGH,
    qmcSample = qmcSample,
    qmcType = qmcType,
		delta_parallel = delta_parallel, 
		maxit_out = maxit_out,
		x_tol_out = x_tol_out,
    fx_tol_out = fx_tol_out,
		verbose_out = verbose_out,	
    opt_method = opt_method,
    method_control_list = method_control_list,
    with_ses = with_ses,
    est_hessian = est_hessian,
    print_warning_vcov = print_warning_vcov )
	return( args )
}