
mptmem_modelstats_sigmaback <- function( parm = NULL, parm_list = NULL, 
  parm_table = NULL, type_sigma = NULL )
{
  #- include parm in parm_list:
  parm_list <- mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- compute SIGMA
  if ( type_sigma == "CD" ) {
    est <- rep( NA, length( parm ) )
    S <- parm_list[["S"]]   
    SIGMA <- t(S) %*% S
    #- further info:
    idx <- which( parm_table$mat == "S" )
    for ( i in 1:length(idx ) ) {
      pos1 <- parm_table[ idx[i], c("row") ]
      pos2 <- parm_table[ idx[i], c("col") ]
      est[ idx[i] ] <- SIGMA[ pos1, pos2 ]
    }
    parm_table$mat[ idx ] <- "SIGMA"
    est[-idx ] <- parm[-idx ]
  } 
  if ( type_sigma == "FA" ) {
    LAM <- parm_list[["LAM"]]
    PSI <- parm_list[["PSI"]]
    SIGMA <- LAM %*% t(LAM) + PSI
    #- further info:
    idx <- which( parm_table$mat == "LAM" )
    mpt_info <- parm_table[idx,c("lhs","row")]
    mpt_info <- mpt_info[ order( mpt_info$row ), ]
    #- make parm_table:
    p <- ncol( SIGMA )
    par <- (p*(p+1))/2 
    lhs <- rhs <- row <- col <- est <- rep( NA, par )
    op  <- rep( "~~", par ) 
    mat <- rep( "SIGMA", par )
    lauf <- 1
    for( i in 1:p ) {
      for ( j in i:p ) {
        row[lauf] <- i
        col[lauf] <- j
        est[lauf] <- SIGMA[i,j]
        lauf <- lauf + 1
      }
    }
    lhs <- mpt_info$lhs[ row ]
    rhs <- mpt_info$lhs[ col ]
    tmp_table <- data.frame( lhs = lhs, op = op, rhs = rhs, mat = mat, row = row, 
      col = col )
    #- add other parms:
    idx <- which( parm_table$mat %in% c("MU","GAM") )
    parm_table <- rbind( tmp_table, parm_table[ idx, c("lhs","op","rhs","mat","row","col") ] )
    est <- c( est, parm[ idx ] )
    parm_table$index <- seq( 1, length( est ), 1 )
  } 
  return( list( parm_table = parm_table, parm = est ) )
}

mptmem_modelstats <- function( parm = NULL, parm_list = NULL, parm_table = NULL, 
  catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = NULL, 
  type_mpt = NULL, type_sigma = NULL, raneff_list = NULL, agh_list = NULL, 
  qmc_pts = NULL, use_rcpp = NULL, dev = NULL, hessian = NULL, with_ses = TRUE, 
  est_hessian = TRUE )
{
  #- default for warning_vcov:
  warning_vcov <- NULL
  P <- length( parm )
  #- adapt parm and parm_table if type_sigma %in% c("CD","FA")
  if ( type_sigma %in% c("CD","FA") ) {
    tmp <- mptmem_modelstats_sigmaback( parm = parm, parm_list = parm_list, 
      parm_table = parm_table, type_sigma = type_sigma )
    parm_table <- tmp$parm_table
    parm <- tmp$parm 
    type_sigma <- "UN"
  }
  #- compute standard errors:    
  if ( with_ses ) {
    if ( is.null( hessian ) ) {
      if ( est_hessian ) {
        hessian <- nloptr::nl.jacobian( x0 = parm, fn = mptmem_gradient, 
          parm_list = parm_list, parm_table = parm_table, catDat = catDat, 
          perDat = perDat, probmatrix = probmatrix, catmatrix = catmatrix, 
          raneff_list = raneff_list, agh_list = agh_list, qmc_pts = qmc_pts, 
          method = method, type_mpt = type_mpt, type_sigma = type_sigma, 
          use_rcpp = use_rcpp, output = 0 )
      } else {
        hessian <- mptmem_hessian( parm = parm, parm_list = parm_list, 
          parm_table = parm_table, catDat = catDat, perDat = perDat, 
          probmatrix = probmatrix, catmatrix = catmatrix, method = method, 
          type_mpt = type_mpt, type_sigma = type_sigma, raneff_list = raneff_list, 
          agh_list = agh_list, qmc_pts = qmc_pts, use_rcpp = use_rcpp )$hessian
      }
    }
    tmp.ses <- mptmem_utils_compute_ses( hessian = hessian )
    warning_vcov <- tmp.ses$warning_vcov
    vcov <- tmp.ses$vcov
    se   <- tmp.ses$se
  } 
  
  #- we have to match the parm and the ses to the correct entries in parm_table:
  parm_table$se <- parm_table$est <- NA
  for ( ii in 1:P ) {
    idx <- which( parm_table$index == ii )
    parm_table[ idx, ]$est <- parm[ii]
    parm_table[ idx, ]$se <- se[ii]
  }
  
  parm_table$z <- parm_table$est/parm_table$se
  parm_table$p <- 2 * pnorm(-abs( parm_table$z ) )
  parm_table$lCI <- parm_table$est - 1.96*parm_table$se
  parm_table$uCI <- parm_table$est + 1.96*parm_table$se

  #- add fixed parms:
  idx <- which( !( is.na( parm_table$fixed ) ) )
  if ( length( idx ) > 0L ) {
    parm_table[idx,]$est <- parm_table[idx,]$fixed
  }

  #- compute fit measures:
  logLik   <- -0.5*dev 
  Deviance <- dev
  aic <- dev + 2*P
  bic <- dev + 2*P*log( sum( catDat ) )

  #- include final parm in parm_list:
  parm_list <- mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  
  #- output:
  out <- list( parm_table = parm_table, parm_list = parm_list, vcov = vcov, 
    logLik = logLik, Deviance = Deviance, aic = aic, bic = bic, 
    warning_vcov = warning_vcov )
  return( out )
}