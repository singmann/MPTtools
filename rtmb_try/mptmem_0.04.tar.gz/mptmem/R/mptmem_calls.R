
coef.mptmem <- function(object, ...)
{
  return( object$coef )
}

parameterEstimates <- function( object, digits = 3L, ...)
{
  parm_table <- object$parm_table[,c("est","se","lCI","uCI","z","p")]
  parm_table[,c("est","se","lCI","uCI","z","p")] <- round( parm_table[,c("est","se","lCI","uCI","z","p")], digits )
  return( parm_table )
}

summary.mptmem <- function( object, digits = 3L, ...)
{
  mptmem_out( object = object, digits = digits )
}

vcov.mptmem <- function(object, ...)
{
  return( object$vcov )
}

logLik.mptmem <- function (object, ...)
{
    out <- object$logLik
    catDat <- object$data_list$catDat
 	  nobs <- dim( catDat )[1]*dim( catDat )[2]
    attr(out, "df") <- length( object$coef )
    attr( out, "nobs") <- nobs
    class( out ) <- "logLik"
    return( out )
}

predict.mptmem <- function ( object, newdata = NULL, type = c("freq", "prob"), ...)
{
  mptmem_predict( object = object, newdata = newdata, type = type )
}

ranef <- function ( object, center = TRUE, ...)
{
  mptmem_raneffs( object = object, center = center )
}