
mptmem_adapt_pertable <- function( per_table = NULL, type_sigma = NULL ) 
{
  #- changes in case of S:
  if ( type_sigma == "CD") {
    idx <- which( per_table$mat == "SIGMA" )
    per_table$mat[ idx ] <- "S"
  } 
  if ( type_sigma == "FA") {
    idx <- which( per_table$mat == "SIGMA" &
                  per_table$lhs == per_table$rhs )
    per_table$mat[ idx ] <- "PSI"
    #- add Lambda:
    per_table_LAM <- per_table[idx,]
    per_table_LAM$mat <- "LAM"
    per_table_LAM$col <- 1L
    per_table_LAM$op  <- "=~"
    per_table <- rbind( per_table_LAM, per_table )
    #- delete covariance terms:
    idx <- which( per_table$mat == "SIGMA" )
    per_table <- per_table[-idx,]
  } 
  return( per_table )
}

mptmem_add_index_variable <- function( per_table = NULL ) 
{
  #- initialuze vectors:
  starts <- per_table$starts 
  index <- rep( NA, length( per_table$lhs ) )
  #- all free parameters that are no constrained get a single number:
  idx <- which( is.na( per_table$equal) & per_table$free == 1)
  index[ idx ] <- seq( 1, length( idx ), 1 )
  last <- length( idx )
  #- all free parameters that are constrained to be equal get a number:
  idx <- which( !( is.na( per_table$equal ) ) & per_table$free == 1 )
  name <- unique( per_table$equal[ idx ] )
  lauf <- last + 1
  for (i in 1:length(name)) {
    tmp <- which( per_table$equal == name[i] )
    index[tmp] <- lauf
    starts[tmp] <- mean( starts[tmp] )
    lauf <- lauf + 1
  }
  #- add index to per_table:
  per_table$starts <- starts
  per_table$index <- index
  per_table$equal <- per_table$mod.idx <- NULL
  return( per_table )
}

mptmem_get_startvalues <- function( per_table = NULL, probmatrix = NULL, catmatrix = NULL, 
  catDat = NULL, perDat = NULL, type_mpt = NULL, type_sigma = NULL, 
  control = NULL )
{
  #- define start value-, lower- and upper-bound-vector 
  starts <- numeric( dim( per_table )[1] )
  low <- rep( -Inf, dim( per_table )[1] )
  up <- rep( Inf, dim( per_table )[1] )
  #- start values for variance and covariance parms depending on type_sigma:
  varCatDat <- max( apply( catDat, 2, var ) ) + 0.1
  if ( type_sigma == "UN" ) {
    ind1 <- which( per_table$op == "~~" &
                   per_table$lhs == per_table$rhs )
    ind2 <- which( per_table$op == "~~" &
                   per_table$lhs != per_table$rhs )
    starts[ ind1 ] <- 0.50
    low[ ind1 ]    <- -2#-abs( log( varCatDat ) ) #-2
    #up[ ind1 ]     <- abs( log( varCatDat ) )
    starts[ ind2 ] <- 0
  }
  if( type_sigma == "CD" ) {
    ind1 <- which( per_table$op == "~~" &
                   per_table$lhs == per_table$rhs )
    ind2 <- which( per_table$op == "~~" &
                   per_table$lhs != per_table$rhs )
    starts[ ind1 ] <- 0.707
    low[ ind1 ]    <- -10#-sqrt( abs( log( varCatDat ) ) ) #-10
    #up[ ind1 ]     <- sqrt( abs( log( varCatDat ) ) )
    starts[ ind2 ] <- 0
  }
  if( type_sigma == "FA" ) {
    ind1 <- which( per_table$op == "=~" )
    ind2 <- which( per_table$op == "~~" )
    starts[ ind1 ] <- 0.10
    starts[ ind2 ] <- 0.50
    low[ ind1 ] <- -10
    #up[ ind1 ]  <-  10
    low[ ind2 ] <- -2#-abs( log( varCatDat ) ) #-2
    #up[ ind2 ]  <- abs( log( varCatDat ) )
  }
  #- we fit a standard mpt for the start values for MU:
  ind <- which( per_table$op == "~1")
  tmp_parm <- mptmem_single_level_fit( start = runif( length( ind ), 0, 1), catDat = catDat, 
    probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, control = control, 
    modeltest = FALSE )
  starts[ ind ] <- tmp_parm[["parm"]]
  low[ ind ] <- -5
  up[ ind ] <- 5
  #- now we substitute the user-specified starting values in the start value vector
  start.idx <- which(!is.na( per_table$starts ) )
  starts[start.idx] <- per_table$starts[ start.idx ]
  #- add all things to per_table:
  per_table$starts <- starts
  per_table$low <- low
  per_table$up <- up
  #- make output:
  return( per_table )
}

mptmem_optimize_addinformation <- function( per_table = NULL, probmatrix = NULL, 
  catmatrix = NULL, catDat = NULL, perDat = NULL, type_mpt = NULL, type_sigma = NULL,
  control = NULL )
{
  #- we have to adapt the parm_matrix in case type_sigma != "UN"
  if ( type_sigma != "UN" ) {
    per_table <- mptmem_adapt_pertable( per_table = per_table, 
      type_sigma = type_sigma ) 
  }
  #- we add an index-variable that respects equality constraints:
  per_table <- mptmem_add_index_variable( per_table = per_table )
  #- some checks:
  if ( control$opt_method == "newton_raphson" & any( table( per_table$index, useNA = c("no") ) > 1 ) ) {
    stop("Newton-Raphson is not available for models with equality constraints.") }
  if ( type_sigma == "FA" & any( table( per_table$index, useNA = c("no") ) > 1 ) ) {
    stop("Factor analysis is not available for models with equality constraints.") }   
  #- define start value-, lower- and upper-bound-vector: 
  per_table <- mptmem_get_startvalues( per_table = per_table, probmatrix = probmatrix, 
    catmatrix = catmatrix, catDat = catDat, perDat = perDat, type_mpt = type_mpt, 
    type_sigma = type_sigma, control = control )
  #- we make final parm_table:
  per_table$s <- 0
  per_table$names <- "i"
  mpt_parms <- unique( per_table$lhs )
  lP <- length( mpt_parms )
  parm_table <- data.frame( lhs = mpt_parms, op = rep("~1", lP), rhs = mpt_parms, 
    fixed = rep( NA, lP ), mat = rep( "MPT", lP ), row = rep( 1, lP ), 
    col = rep( 1, lP ), names = mpt_parms, s = c(1:lP), starts = rep( NA, lP ), 
    low = rep( 0, lP ), up = rep( 1, lP ), index = rep( NA, lP ) )
  names <- colnames( parm_table )
  parm_table <- rbind( parm_table, per_table[,names] )
  #- some final things:
  parm_table$unid <- parm_table$index
  parm_table$unid[ is.na( parm_table$unid ) ] <- 0
  parm_table$unid[ duplicated( parm_table$unid ) ] <- 0
  parm_table <- parm_table[ order(parm_table$unid), ]
  npar <- max( parm_table$index, na.rm = TRUE )
  parm_idx <- match( seq_len( npar ), parm_table$unid )
  attr( parm_table, "npar") <- npar
  attr( parm_table, "parm_idx" ) <- parm_idx
  #- add other attributes:
  attr( parm_table, "mmRows") <- attr( per_table, "mmRows")
  attr( parm_table, "mmCols") <- attr( per_table, "mmCols")
  #- return parm_table
  return( parm_table )
}