
mptmem_getmodes_llfct <- function( us = NULL, tCatDat = NULL, tPerDat = NULL, parm_list = NULL, 
	probmatrix = NULL, catmatrix = NULL, iSIGMA = NULL, type_mpt = NULL )
{
	#- substitute ut:
	theta <- mptmem_llfct_prepare( us = us, type_mpt = type_mpt )
  #- compute prob of a category system:
  P_Ck <- mptmem_llfct_catprob_pureR( theta = theta, probmatrix = probmatrix, 
  	catmatrix = catmatrix )
  #- loglik data:
  ll_data <- sum( tCatDat * log( P_Ck ) )
	#- overall loglik:
	ll <- ll_data - 0.5*( ( t( us - tPerDat ) %*% iSIGMA ) %*% ( us - tPerDat ) ) 
	# - output
  return( -1*ll )
}

#- this function estimates the raneffs u for each person:

mptmem_getmodes <- function( parm = NULL, parm_table = NULL, parm_list = NULL, 
	catDat = NULL, perDat = NULL, probmatrix = NULL, catmatrix = NULL, 
	type_mpt = NULL, type_sigma = NULL )
{
	#- include parm in parm_list:
  parm_list <- mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
   	parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1]
  #- get SIGMA: 
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {  
    S <- parm_list[["S"]] 
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    LAM <- parm_list[["LAM"]]
    PSI <- parm_list[["PSI"]]
    SIGMA <- LAM %*% t(LAM) + PSI
  }
	s <- dim( SIGMA )[1] # how many random effects
	iSIGMA <- solve( SIGMA )
	MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- MUmat }
  #- let's go:
	raneff_list <- vector( "list", T )
	for ( tt in 1:T ) {
		#- get a person's data:
    tCatDat <- catDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
		#- Step 2: estimate posterior mode 
		tmp_res <- stats::nlminb( start = rep(0.1, s), objective = mptmem_getmodes_llfct, tCatDat = tCatDat, 
			tPerDat = tPerDat, parm_list = parm_list, probmatrix = probmatrix, catmatrix = catmatrix, 
			iSIGMA = iSIGMA, type_mpt = type_mpt )
    #- Step 3: estimate other stuff..
    MODE <- tmp_res$par
    OBJ  <- tmp_res$objective
    HESS <- numDeriv::hessian( func = mptmem_getmodes_llfct, x = MODE, tCatDat = tCatDat,
      tPerDat = tPerDat, parm_list = parm_list, probmatrix = probmatrix, catmatrix = catmatrix, 
      iSIGMA = iSIGMA, type_mpt = type_mpt )
		iHESS <- solve( HESS )
    CHOL <- chol( iHESS )
    DET <- determinant( iHESS, log = FALSE )$modulus
    #- Save:
    raneff_list[[ tt ]] <- list( MODE = MODE, OBJ = OBJ, iHESS = iHESS, CHOL = CHOL, DET = DET )
	}
	#- output
	return( raneff_list )
}