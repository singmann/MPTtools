
################################
###        mpt part
################################

mptmem_partable_addelements_mpt <- function( mpt.list = NULL ) 
{
  #- get the parameters across all trees:
  pcoef <- unique( mpt.list$pathcoef )
  #- get the number of categories ( this is sufficient because the user specifies
  #  different names for the categories within and across trees )
  Cat <- unique( mpt.list$cat  )  
  nCat <- length( Cat ) 
  #- make a temporary list:
  tmp.list <- list( type = character(0), tree = character(0), cat = character(0), 
    branch = integer(0), pathcoef = character(0), present = integer(0), parm = integer(0),
    parminv = integer(0) )
  #- go through the tree and the categories in the trees and add missing coefs:
  for ( i in 1:nCat ) {
  	#- get relevant tree:
  	id1 <- which( mpt.list$cat == Cat[i] )
  	tmp.cat <- lapply( mpt.list ,function(x) x[id1])
  	#- get number of branches within a category:
  	Branch <- unique( tmp.cat$branch )  
  	nBranch <- length( Branch ) 
  	#- go through each cat and add parm
  	for ( j in 1:nBranch ) {
  		id2 <- which( tmp.cat$branch == Branch[j] )
  		tmp <- lapply( tmp.cat ,function(x) x[id2])
  		if ( !all( pcoef %in% tmp$pathcoef ) ) {
  			miss <- setdiff( pcoef, tmp$pathcoef )
  			nmiss <- length( miss )
  			#- define empty vectors:
  			tmp.list$type <- c( tmp.list$type, rep("MPT", nmiss ) ) 
  			tmp.list$tree <- c( tmp.list$tree, rep( tmp$tree[1], nmiss ) ) 
  			tmp.list$cat  <- c( tmp.list$cat, rep( Cat[i], nmiss ) )
  			tmp.list$branch <- c(tmp.list$branch, rep( Branch[j], nmiss ) )
  			tmp.list$pathcoef <- c( tmp.list$pathcoef, miss ) 
  			tmp.list$present <- c( tmp.list$present, rep( 0, nmiss ) )
        tmp.list$parm <- c( tmp.list$parm, rep( 0, nmiss ) )
  			tmp.list$parminv <- c( tmp.list$parminv, rep( 0, nmiss ) )
  		}
  	}
  }
  #- make tables and bind them:
  tmp.list_asdf <- as.data.frame( tmp.list, stringsAsFactors = FALSE )
  mpt.list_asdf <- as.data.frame( mpt.list, stringsAsFactors = FALSE )
  mpt.table <- rbind( mpt.list_asdf, tmp.list_asdf )
  mpt.table <- mpt.table[order(mpt.table$tree, mpt.table$cat, mpt.table$branch, 
  	mpt.table$pathcoef),]
  return( mpt.table )
} 

mptmem_partable_to_matrix_mpt <- function( mpt.table = NULL, add.attributes = TRUE ) 
{
  #- we have to delete the paths that appear more than once because they are powers
  #  (e.g., u*u)
  tmp.table <- mpt.table
  #- we first determine the number of duplicated rows:
  tmp.table$pow <- with( tmp.table, ave( present, cat, branch, pathcoef, parm, FUN = length ) )
  #- we now delete the respective rows:
  #idx <- which( duplicated( tmp.table ) )
  #tmp.table <- tmp.table[-idx,]
  tmp.table <- tmp.table[!duplicated( tmp.table ),]
  #- multiply power col time parm and parm_inv row:
  tmp.table$parm <- with( tmp.table, parm*pow )
  tmp.table$parminv <- with( tmp.table, parminv*pow )
  #- what is left is to combine the rows with same parm and parminv in cat and branch:
  mpt.table <- aggregate( tmp.table[,c("present","parm","parminv")], by = list( tree = 
    tmp.table$tree, cat = tmp.table$cat, branch = tmp.table$branch, 
    pathcoef = tmp.table$pathcoef ), sum )
  mpt.table <- mpt.table[order(mpt.table$tree, mpt.table$cat, mpt.table$branch, 
    mpt.table$pathcoef),]
  return( mpt.table )
}

################################
###       person part
################################

mptmem_partable_person <- function( per.list = NULL, mpt.parms = NULL, 
	auto.cov = TRUE, auto.int = TRUE )
{
  #- extract 'names' of various types of variables:
  tmp.list <- per.list

  #- -------------------------
  #-  1. some things to start
  #- -------------------------

  #- we determine variables that are outcomes or that are predictors:
  ov.names.y <- mptmem_partable_vnames_person( tmp.list, type = "ov.y" ) # dependent ov
  ov.names.x <- mptmem_partable_vnames_person( tmp.list, type = "ov.x" ) # independent ov 
  #- we also determine variables that are means:
  #ov.means <- mpt_partable_vnames_person( tmp.list, type = "ov.means" )
  #- check whether mpt-variables are predictors:
  if ( any( mpt.parms %in% ov.names.x ) ) {
  	stop("It is currently not allowed that mpt parameters are predictors.")
  }
  #- check whether person covariates are outcomes:
	if ( !all( ov.names.y %in% mpt.parms ) ) {
  	stop("It is currently not allowed that person variables are outcomes.")
  }

  #- -----------------------------------------
  #-   2. Construct a default parameter table 
  #- -----------------------------------------

  #- empty vectors:
  lhs <- character(0)
  rhs <- character(0)
  #- we always estimate all variances terms between the mpt-vars:
  lhs <- c( mpt.parms )
  rhs <- c( mpt.parms )
  #- at present, we always estimate all covariances terms between the mpt-vars:
  if ( auto.cov ) {
	  tmp <- utils::combn( mpt.parms, 2 )
	  lhs <- c(lhs, tmp[1,])
	  rhs <- c(rhs, tmp[2,])
  }
  #- add op and mod.idx:
  op <- rep( "~~", length( lhs ) )
  mod.idx <- rep( 0, length( lhs ) )
  #- at present, we always estimate all covariances terms between the mpt-vars:
  if( auto.int ) {
    tmp <- c( mpt.parms )
    lhs <- c(lhs, tmp)
    rhs <- c(rhs, tmp)
    op  <- c(op,  rep("~1", length(tmp)))
    mod.idx <- c(mod.idx,rep(0,length(tmp)))
  }
  #- construct the default table:
  default <- data.frame( lhs = lhs, op = op, rhs = rhs, mod.idx = mod.idx,
  	stringsAsFactors = FALSE )

  #- ----------------------------------------------------------------
  #-  3. construct the user table and compare with the default table 
  #- ----------------------------------------------------------------
  
  user <- as.data.frame( tmp.list, stringsAsFactors = FALSE )
  #- check for duplicated elements in user's table:
  tmp <- user[,2:4]
  idx <- which( duplicated( tmp ) )
  if( length( idx ) > 0L ) {
    warning("There are duplicated elements in model syntax.
             They have been ignored.")
    user <- user[-idx,]
  }
  #- combine user's and default table, check for duplicated elements
  #  and these duplicated elements from default
  tmp <- rbind( default[,1:3], user[,2:4] )
  idx <- which( duplicated( tmp, fromLast = TRUE ) ) 
  if( length( idx ) ) { default <- default[-idx,] }

  #- --------------------------------------------
  #-  4. We construct the final parameter table
  #- --------------------------------------------
  nUser <- dim( user )[1]
  nDefault <- dim( default )[1]
  lhs    <- c( user$lhs, default$lhs)
  op     <- c( user$op,  default$op)
  rhs    <- c( user$rhs, default$rhs)
  fixed  <- c( user$fixed, rep( as.numeric(NA), nDefault ) )
  starts <- c( user$starts,rep( as.numeric(NA), nDefault ) ) # user svs
  equal  <- c( user$equal, rep( as.numeric(NA), nDefault ) )
  mod.idx <- c( user$mod.idx, default$mod.idx )  # modified or not
  free <- c( user$free, rep( 1, nDefault ) )
  user <- c( rep( 1, nUser ), rep( 0, nDefault ) )
  per.table <- data.frame( lhs = lhs, op = op, rhs = rhs, fixed = fixed,
  	starts = starts, equal = equal, mod.idx = mod.idx, free = free, user = user,
  	stringsAsFactors = FALSE )
  return( per.table )
}

# this functions determines the names of the different variables

mptmem_partable_vnames_person <- function( per.list = NULL, type = NULL )
{
  #- check for empty list:
  if( length( per.list$lhs) == 0 ) return( character(0L) )
  
  #- make an output list:
  out <- vector("list", length = 1L )
  #  mpt latent variables:
  out$ov.y <- vector("list", length = 1L)
  out$ov.x <- vector("list", length = 1L)
  #  intercepts of latent variables:
  out$ov.mean <- vector("list", length = 1L)
  
  #- determine all lhs - variables:
  if( "ov.y" %in% type  ) {
    names.ov.y <- unique( per.list$lhs[ per.list$op == "~" ] )
  	out$ov.y <- names.ov.y
  }
  #- determine all rhs - variables:
  if( "ov.x" %in% type  ) {
    names.ov.x <- unique( per.list$rhs[ per.list$op == "~" ] )
  	out$ov.x <- names.ov.x
  }
  #- determine all means: 
	if( "ov.mean" %in% type  ) {
    names.ov.mean <- unique( per.list$lhs[ per.list$op == "~1" ] )
  	out$ov.mean <- names.ov.mean
  }
  
  #- output:
  if( length( type ) == 1L ) {
    out <- unlist( out[[ type ]] )
  } else { out <- out[ type ] }
  return( out )
}

mptmem_partable_to_matrix_person <- function( per.table = NULL, mpt.parms = NULL, 
  extra = TRUE ) 
{
  #- temporary object
  target <- per.table
  #- prepare output
  n <- length( target$lhs )
  tmp.mat <- character(n)
  tmp.row <- integer(n)
  tmp.col <- integer(n)
  #- predictors?
  if( any( per.table$op == "~" ) ) {
    gam <- TRUE
  } else { 
    gam <- FALSE 
  }

  #- make matrices:
  #  variance-covariance matrices "~~" variables
  idx <- which( target$op == "~~"  &
                target$lhs %in% mpt.parms &
                target$rhs %in% mpt.parms )
  tmp.mat[idx] <- "SIGMA"
  tmp.row[idx] <- match( target$lhs[idx], mpt.parms )
  tmp.col[idx] <- match( target$rhs[idx], mpt.parms )
  ncol_SIGMA <- length( mpt.parms )
  nrow_SIGMA <- length( mpt.parms )
  #  matrix for means:
  idx <- which( target$op == "~1" &
                target$lhs %in% mpt.parms )
  tmp.mat[idx] <- "MU"
  tmp.row[idx] <- match(target$lhs[idx], mpt.parms )
  tmp.col[idx] <- 1L
  nrow_MU <- length( target$lhs[idx] )
  #  predictors for the means
  if ( gam ) {
    ov.names.x <- mptmem_partable_vnames_person( target, type = "ov.x" ) 
    idx <- which( target$rhs %in% ov.names.x &
                  target$op == "~")
    tmp.mat[idx] <- "GAM"
    tmp.row[idx] <- match( target$lhs[idx],mpt.parms )
    tmp.col[idx] <- match( target$rhs[idx],ov.names.x )
    ncol_GAM <- length( ov.names.x )
    nrow_GAM <- length( mpt.parms )
  } else {
    ncol_GAM <- 0
    nrow_GAM <- 0
  }

  #- add the information to per.table:
  per.table$mat <- tmp.mat
  per.table$row <- tmp.row
  per.table$col <- tmp.col
  if( extra ) {
    mmRows <- list( MPT =   nrow_MU,
                    SIGMA = nrow_SIGMA,
                    MU =    nrow_MU,
                    GAM =   nrow_GAM,
                    S =     nrow_SIGMA,
                    LAM =   nrow_SIGMA,
                    PSI =   nrow_SIGMA )
    mmCols <- list( MPT = 1L,
                    SIGMA = ncol_SIGMA,
                    MU = 1L,
                    GAM =   ncol_GAM,
                    S =     ncol_SIGMA,
                    LAM = 1L,
                    PSI =   ncol_SIGMA )
    attr( per.table, "mmRows") <- mmRows
    attr( per.table, "mmCols") <- mmCols
  } 
  return( per.table )
}