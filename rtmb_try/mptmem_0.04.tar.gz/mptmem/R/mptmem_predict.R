
mptmem_predict <- function( object = NULL, newdata = NULL, type = c("freq", "prob") )
{
  #- collect arguments:
  type <- match.arg( type )
  parm_list <- object$parm_list
  raneff_list <- object$raneff_list
  agh_list <- object$agh_list
  qmc_pts <- object$qmc_pts
  catDat <- object$catDat
  perDat <- object$perDat
  probmatrix <- object$probmatrix
  catmatrix <- object$catmatrix
  method <- object$method
  type_mpt <-  object$type_mpt
  if ( is.null( newdata ) ) {
    #- get random effects for single persons: 
    raneffs <- mptmem_raneffs( object = object )$means
    #- get relevant matrices: 
    MU <- parm_list[["MU"]]
    GAM <- parm_list[["GAM"]]
    #- compute person-specific mean:
    if ( dim( GAM )[1] != 0 ) {
      TOperDat <- MU + GAM%*%perDat
    } else { TOperDat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE ) }
    #- for each person, we compute predicted probs and/or frequencies
    T <- dim( catDat )[1]
    tt_prob <- vector( "list", T )
    for ( tt in 1:T ) {
      #- compute a persons u-values:
      tus <- TOperDat[tt,] + raneffs[tt,-1]
      #- get a person's random effect modes:
      theta <- mptmem_llfct_prepare( us = tus, type_mpt = type_mpt )
      #- compute probabilities of the categories:
      tt_prob[[tt]] <- mptmem_llfct_catprob_pureR( theta = theta, probmatrix = probmatrix, 
        catmatrix = catmatrix )
    }
    prob <- do.call( "rbind", tt_prob )  
  } else {
    stop("The newdata-argument is currently not avaiable.")
  }
  #- consider freq-argument:
  if ( type == "freq" ) {
      freq <- prob * catDat 
      out <- list( prob = prob, freq = freq )
  } else { out <- prob }
  return( out )
}