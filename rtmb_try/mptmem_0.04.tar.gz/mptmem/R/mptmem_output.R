
# NOTE: this function is inspired by srm print function
mptmem_print_optinfos <- function( object = NULL, digits = 3L )
{
  #- define the texts:
  texts <- c("The approximation method is ",
             "The link function is ",
             "Type of Sigma is ",
             "",
             "The number of estimated parameters is: ",
             "Log-likelihood: ",
             "Deviance: ",
             "AIC: ",
             "BIC: ",
             "",
             "Number of persons: ",
             "Number of categories: ",
             "Number of mpt parameters: ")
  #- type of sigma value:
  name_type_sigma <- NA
  if ( object$type_sigma == "UN" ) {
    name_type_sigma <- "Unstructured"
  } else if ( object$type_sigma == "CD" ) {
    name_type_sigma <- "Cholesky Decomposition"
  } else if ( object$type_sigma == "FA" ) {
    name_type_sigma <- "Factor Analysis"
  } 
  #- the values
	values <- c( object$method,
               object$type_mpt,
               name_type_sigma,
               "",
               length( object$coef),
               round( object$logLik, digits),
               round( object$Deviance, digits),
               round( object$aic, digits),
               round( object$bic, digits),
               "",
               dim( object$data_list$catDat )[1],
               dim( object$data_list$catDat )[2],
               length( unique( fit$mpt_table$pathcoef ) ) )
  #- print texts
  char.format <- paste("%3s%-", 14, "s", sep = "")
  cat("\nGeneral information:\n\n")
  for ( i in 1:length( texts ) ) {
    tmp <- paste( sprintf( char.format, "", texts[i] ), values[i], sep = "" )                       
    cat(tmp)
    cat("\n")
  }
  cat("\n")
}

# NOTE: this function is inspired by lavaans print function
mptmem_print_parameters <- function( object = NULL, digits = 3L )
{
  #- get parmtable from object:
  parm_table <- object$parm_table
  #- we round the values in the table:
  parm_table[,c("est","se","z","p")] <- round( parm_table[,c("est","se","z","p")], digits )
  #- make parmtable smaller:
  #idx <- which( parm_table$fixed %in% c( 1, NA ) )
  #parm_table <- parm_table[idx,]
  #- get "level":
  level <- c( "%Within%","%Person%")
  parm_table$level <- ifelse( !(parm_table$mat %in% c("SIGMA","GAM","MU") ), 
    level[1], level[2] )
  #- ----------------------------
  #-     make character matrix
  #- ----------------------------
  y <- parm_table[,c("lhs","est","se","z","p")]
  m <- as.matrix( format.data.frame( y, na.encode = FALSE, justify = "right") )
  rownames( m ) <- rep( "", nrow(m) ) # make empty row names
  #- in case the se is NA we have to insert nothing...
  idx <- which( is.na( parm_table$se ) )
  if( length( idx ) > 0L ) {
    m[idx, "se"] <- ""
    m[idx, "z"] <- ""
    m[idx, "p"] <- ""
  }
  # rename some column names
  colnames(m) <- c("","Estimate","Std.Err","z-value","P(>|z|)")
  #- --------------------
  #-    start printing
  #- --------------------
  char.format <- paste("%3s%-", 14, "s", sep = "")
  sections <- c("Intercepts","Regressions","Variances","Covariances")
  cat("Parameter estimates:")
  for( l in 1:2 ) {
		#- level header
    cat( "\n\n" )
    cat( level[l],"\n", sep="" )
    #- check whether there are any parameters on within level:
    check <- which( parm_table$level == level[l] & ! is.na( parm_table$est ) )
    if( length( check ) == 0L ) {
    	cat("\n", "No parameters for %Within%.", sep = "")
    	next
    }
    #- per section:
    for( s in sections ) {
    	#- let's go:
      if( s == "Intercepts" ) {
        row_idx <- which( parm_table$op == "~1" & 
        									parm_table$level == level[l] & 
        									!is.na(parm_table$est) )
        if( length(row_idx) == 0L ) next
        tmp <- rep( "", length( row_idx ) )
        m[row_idx,1] <- sprintf(char.format, tmp, parm_table$rhs[row_idx] )
			} else if( s == "Regressions" ) {
				row_idx <- which( parm_table$op == "~" &
													parm_table$level == level[l] )
        if( length(row_idx) == 0L ) next
        tmp <- rep( "", length( row_idx ) )
        m[row_idx,1] <- sprintf(char.format, tmp, parm_table$rhs[row_idx] )
			} else if( s == "Covariances"  ) {
        row_idx <- which( parm_table$op == "~~" &
                          parm_table$lhs != parm_table$rhs &
													parm_table$level == level[l] )
        if( length( row_idx ) == 0L ) next
        tmp <- rep( "", length( row_idx ) )
        m[row_idx,1] <- sprintf(char.format, tmp, parm_table$rhs[row_idx] )
			} else if( s == "Variances"  ) {
				row_idx <- which( parm_table$op == "~~" & 
													parm_table$lhs == parm_table$rhs &
													parm_table$level == level[l] )
				if( length( row_idx ) == 0L) next
        tmp <- rep( "", length( row_idx ) )
        m[row_idx,1] <- sprintf(char.format, tmp, parm_table$rhs[row_idx] )
			} else { row_idx <- integer(0L) }
			
			#- we delete repeated lhs names in case of latent vars....
			if( s %in% c("Regressions","Covariances") ) {
				nel <- length(row_idx)
        M <- matrix("", nrow = nel*2, ncol = ncol(m))
        colnames(M) <- colnames(m)
        rownames(M) <- rep("", NROW(M))

        LHS <- paste( parm_table$lhs[row_idx], parm_table$op[row_idx])
        lhs_idx <- seq(1, nel*2, 2L)
        rhs_idx <- lhs_idx + 1

        tmp <- rep("", length(LHS))
        M[lhs_idx,  1 ] <- sprintf("%1s%-15s", tmp, LHS)
        M[rhs_idx, ] <- m[row_idx,]
        idx <- duplicated(M[,1])
        if ( s %in% c("Regressions","Covariances") ){
          idx2 <- M[,"Estimate"] == ""                        
          idx <- idx & idx2
        }
        #M[,1] <- ifelse( idx, "", M[,1])
        M <- rbind( M[!idx, ] )
				cat("\n", s, ":\n", sep = "")
        print(M, quote = FALSE)
        # Regular
      } else {
        M <- m[row_idx,,drop=FALSE]
        colnames(M) <- colnames(m)
        rownames(M) <- rep("", NROW(M))
        cat("\n", s, ":\n", sep = "")
        print(M, quote = FALSE)
      }
    } # sections
  } # levels
  cat("\n")
  invisible( m )
}


mptmem_out <- function( object = NULL, digits = 3L )
{
    mptmem_print_optinfos( object = object, digits = digits )
    mptmem_print_parameters( object = object, digits = digits )
}
