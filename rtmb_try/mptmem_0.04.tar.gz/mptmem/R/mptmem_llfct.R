
#######################################################################################

mptmem_llfct_prepare <- function( us = NULL, type_mpt = NULL )
{
  #- compute scaled parm:
  if ( type_mpt == "logit" ) {
    parm <- exp( us )/( 1 + exp( us ) )
  } else if ( type_mpt == "probit" ) {
    parm <- pnorm( us, 0 , 1 )
  } 
  #- output
  return( parm ) 
}

mptmem_llfct_catprob_pureR <- function( theta = NULL, catmatrix = NULL, probmatrix = NULL ) 
{
  #- extract no. of parms:
  S <- length( theta )
  #- extract no. of independent sub categories:
  K <- dim( catmatrix )[1]
  #- vector for over probabilities:
  P_Ck <- rep( 0, K )
  #- iterate over K:
  idx1 <- 1
  idx2 <- S
  for ( k in 1:K ) {
    #- get no. of subtrees in subcategory k:
    Ikj <- catmatrix[ k, 3 ]
    #- loop through subcategories:
    for ( i in 1:Ikj ) {
      #- get branch matrix:
      AB <- probmatrix[idx1:idx2,]
      #- get single path prob:
      tmp1 <- tmp2 <- 1
      for ( s in 1:S ) {
        if ( AB[s,4] != 0 ) {
          tmp1 <- tmp1*theta[s]^AB[s,4] }
        if ( AB[s,5] != 0 ) {
          tmp2 <- tmp2*(1-theta[s])^AB[s,5] }
      }
      idx1 <- idx1 + S
      idx2 <- idx2 + S
      P_Ck[k] <- P_Ck[k] + tmp1*tmp2
    } # Ikj
  } # K
  return( P_Ck )
}

mptmem_llfct_data <- function( us = NULL, tCatDat = NULL, probmatrix = NULL, 
  catmatrix = NULL, type_mpt = NULL )
{
  #- prepare the parm-vector:
  theta <- mptmem_llfct_prepare( us = us, type_mpt = type_mpt )
  #- compute probabilities of the categories:
  P_Ck <- mptmem_llfct_catprob_pureR( theta = theta, probmatrix = probmatrix, 
    catmatrix = catmatrix )
  #- compute likelihood:
  llfct <- prod( P_Ck^tCatDat ) # sum( tCatDat * log( P_Ck ) )
  #- return outcome
  return( llfct )
}

##################################################################################

mptmem_llfct_agh <- function( tCatDat = NULL, tPerDat = NULL, raneffs = NULL, 
    parm_list = NULL, agh_list = NULL, probmatrix = NULL, catmatrix = NULL,
    type_mpt = NULL, SIGMA = NULL, use_rcpp = NULL )
{
  #- get quadrature information
  tmp.pts <- agh_list[["tmp.pts"]]
  tmp.exp <- agh_list[["tmp.exp"]] # exp-transformed quadrature points
  tmp.wghexp <- agh_list[["tmp.wghexp"]] 
  #- get information on the nmber of dimensions of SIGMA
  Q <- dim( SIGMA )[1]
  #- estimate mode of theta and hessian matrix of theta
  MODE <- raneffs[["MODE"]]
  CHOL <- raneffs[["CHOL"]]
  DET  <- raneffs[["DET"]] 
  #- compute transformed quadrature points
  tmp.pts <- tmp.pts%*%CHOL
  tmp.pts <- sweep( tmp.pts, 2, MODE, "+") 
  #- compute normal density values of quadratute points given Gom
  tmp.den <- mvtnorm::dmvnorm( tmp.pts, tPerDat, SIGMA )
  #- compute conditional likelihood values for the adapted quadrature points
  if ( use_rcpp ) {
    tmp.fun <- mptmem_llfct_data_rcpp( pts = tmp.pts, tCatDat = tCatDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt)
  } else { 
    tmp.fun <- apply( tmp.pts, 1, mptmem_llfct_data, tCatDat = tCatDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt ) 
  }
  #- compute the produt of values, density and weights
  out <- apply( cbind( tmp.wghexp, tmp.den, tmp.fun ), 1, prod )
  #- compute the sum of the products and multiple them with pi and det
  marginal_llfct <- as.numeric( ( 2*pi )^(Q/2) * sqrt( DET ) * sum( out ) )
  return( marginal_llfct )
}

 mptmem_llfct_laplace <- function( tCatDat = NULL, tPerDat = NULL, raneffs = NULL, 
    parm_list = NULL, probmatrix = NULL, catmatrix = NULL, type_mpt = NULL, 
    SIGMA = NULL, use_rcpp = NULL )
{
  #- get quadrature information:
  Q <- dim( SIGMA )[1]
  #- estimate mode of theta and hessian matrix of theta:
  MODE <- raneffs[["MODE"]]
  DET  <- raneffs[["DET"]] 
  #- compute conditional likelihood value for the mode:
  tmp.pts <- matrix( MODE, nrow = 1 )
  if ( use_rcpp ) {
    fun <- mptmem_llfct_data_rcpp( pts = tmp.pts, tCatDat = tCatDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt )
  } else {
    fun <- mptmem_llfct_data( us = tmp.pts, tCatDat = tCatDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt )
  }
  #- compute the normal density value for the mode:
  den <- mvtnorm::dmvnorm( MODE, tPerDat, SIGMA )
  #- compute Laplace approximation:
  marginal_llfct <- as.numeric( ( 2*pi )^(Q/2) * sqrt( DET ) * fun * den )
  return( marginal_llfct )
}

mptmem_llfct_qmc <- function( tCatDat = NULL, tPerDat = NULL, raneffs = NULL, 
  parm_list = NULL, probmatrix = NULL, catmatrix = NULL, type_mpt = NULL, 
  SIGMA = NULL, qmc_pts = NULL, use_rcpp = NULL )
{
  #- dimension of SIGMA
  Q <- dim( SIGMA )[1]
  #- get mode and hessian matrix:
  MODES <- raneffs[["MODE"]]
  CHOLS <- raneffs[["CHOL"]]
  iHESS <- raneffs[["iHESS"]]
  #- transform pts:
  qmc_pts <- qmc_pts%*%CHOLS
  qmc_pts <- sweep( qmc_pts, 2, MODES, "+") 
  #- compute normal density values of the points:
  tmp_den1 <- mvtnorm::dmvnorm( qmc_pts, tPerDat, SIGMA )
  tmp_den2 <- mvtnorm::dmvnorm( qmc_pts, MODES, iHESS )
  #- compute conditional likelihood values for the points:
  if ( use_rcpp ) {
    out <- mptmem_llfct_data_rcpp( pts = qmc_pts, tCatDat = tCatDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt)
  } else { 
    out <- apply( qmc_pts, 1, mptmem_llfct_data, tCatDat = tCatDat, probmatrix = probmatrix, 
      catmatrix = catmatrix, type_mpt = type_mpt ) 
  } 
  #- compute the mean of these values:
  out <- out*tmp_den1*(1/tmp_den2) 
  marginal_llfct <- mean( out )
  return( marginal_llfct )
}

##############################################################################################

mptmem_llfct <- function( parm = NULL, parm_list = NULL, parm_table = NULL, catDat = NULL, 
  perDat = NULL, probmatrix = NULL, catmatrix = NULL, method = "AGH", type_mpt = NULL, 
  type_sigma = NULL, raneff_list = NULL, agh_list = NULL, qmc_pts = NULL, use_rcpp = TRUE, output = 0 )
{
  #- include parm in parm_list:
  parm_list <- mptmem_include_freeparms( parm = parm, parm_list = parm_list, 
    parm_table = parm_table )
  #- collect data and get no. of persons:
  T <- dim( catDat )[1] 
  #- get relevant matrices: 
  if ( type_sigma == "UN" ) {
    SIGMA  <- parm_list[["SIGMA"]]
  } else if ( type_sigma == "CD") {
    S <- parm_list[["S"]]   
    SIGMA <- t(S) %*% S
  } else if ( type_sigma == "FA") {
    LAM <- parm_list[["LAM"]]
    PSI <- parm_list[["PSI"]]
    SIGMA <- LAM %*% t(LAM) + PSI
  }
  MU <- parm_list[["MU"]]
  GAM <- parm_list[["GAM"]]
  MUmat <- matrix( MU, nrow = T, ncol = length( MU ), byrow = TRUE )
  #- compute person-specific mean:
  if ( dim( GAM )[1] != 0 ) {
    TOperDat <- MUmat + perDat %*% t( GAM )
  } else { TOperDat <- MUmat }
  #- let's go:
	tmp_ll <- vector( "list", T )
	for ( tt in 1:T ) {
    #- get a person's data:
    tCatDat <- catDat[tt,]
    #- compute person-specific mean:
    tPerDat <- TOperDat[tt,]
    #- get a person's random effect modes:
    raneffs <- raneff_list[[ tt ]]
    #- approximate the person-specific likelihood with different methods:
    if ( method == "Laplace" ) {
      tmp_ll[ tt ] <- mptmem_llfct_laplace( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, SIGMA = SIGMA,
        use_rcpp = use_rcpp )
    } else if ( method == "AGH" ) { 
      tmp_ll[ tt ] <- mptmem_llfct_agh( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        agh_list = agh_list, probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA, use_rcpp = use_rcpp )
    } else if ( method == "QMC" ) {
      tmp_ll[ tt ] <- mptmem_llfct_qmc( tCatDat = tCatDat, tPerDat = tPerDat, raneffs = raneffs, 
        qmc_pts = qmc_pts, probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
        SIGMA = SIGMA, use_rcpp = use_rcpp )        
    }
  }     
  #- transform tmp_ll to a vector:
  llfct <- do.call( "rbind", tmp_ll )
  #- take the log and sum the elements in tmp.res
  llfct <- sum( log( llfct ) )
  #- outcome
  # if ( is.infinite( llfct ) | is.na( llfct ) ) { llfct <- -100000 }
  return( -2*llfct )
}