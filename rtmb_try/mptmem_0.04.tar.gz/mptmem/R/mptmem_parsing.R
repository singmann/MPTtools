
mptmem_prepare_parsing <- function( model.syntax = NULL ) 
{
  #- Check for empty syntax
  if( is.null( model.syntax ) ) {
    stop("No model is defined.")
  }
  #- newlines for comments:
  model.syntax <- gsub("[#!].*(?=\n)","", model.syntax, perl=TRUE)
  #- remove whitespace prior to split:
  model.syntax <- gsub("[ \t]+", "", model.syntax, perl=TRUE)
  #- break up in lines:
  model <- unlist( strsplit(model.syntax, "\n") )
  # merge multiline formulas and delete null lines
  start.idx <- grep("[~=@%]", model) # [~=@%] we search for this
  end.idx <- c( start.idx[-1]-1, length(model) )
  model.orig <- model
  model <- character( length(start.idx) )
  for(i in 1:length(start.idx)) {
    model[i] <- paste(model.orig[start.idx[i]:end.idx[i]], collapse="")
  }
  return( model )
}

mptmem_parsing_split <- function( model = NULL ) 
{
  #- get positionen of mpt code and person code:
  mpt.idx <- grep( "%Within|%within", model )
  per.idx <- grep( "%Person|%preson", model )
  #- check for empty syntax:
  if( length( mpt.idx ) == 0L) {
    stop("No model for MPT is defined.")
  }
  if( length( per.idx ) == 0L) {
    stop("No model for person is defined.")
  }
  # two cases: person formulas are prior to dyad formulas or
  # it is vice versa
  if ( mpt.idx < per.idx ) {
    model.mpt <- character( per.idx - 2 )
    for(i in 1:length( model.mpt ) ) {
      model.mpt[i] <- model[i+1]
    }
    model.per <- character( length( model ) - per.idx )
    for(i in 1:length( model.per ) ) {
      model.per[i] <- model[i+per.idx]
    }
  } else {
    model.per <- character( mpt.idx - 2 )
    for(i in 1:length(model.per)) {
      model.per[i] <- model[i+1]
    }
    model.mpt <- character( length( model ) - mpt.idx )
    for(i in 1:length(model.mpt)) {
      model.mpt[i] <- model[i+mpt.idx]
    }
  }
  models <- list( model.mpt, model.per )
  return( models )
}

###########################################
###         Parsing mpt part
###########################################

mptmem_parsing_list_mpt <- function( model = NULL ) 
{
  #- define empty vectors:
  mpt.type <- character(0)
  mpt.tree <- character(0)
  mpt.cat  <- character(0)
  mpt.branch <- integer(0)
  mpt.pathcoef <- character(0) 
  mpt.present <- integer(0)
  mpt.parm <- integer(0)
  mpt.parminv <- integer(0)
  #- let's go:  
  iterator <- 0
  for ( i in 1:length(model) )  {
    #- get line to analyse:
    x <- model[i]
    #- some checks:
    x.simple <- gsub("\\\".[^\\\"]*\\\"", "LABEL", x)
    #- ':' operator?
    if( !grepl(":", x.simple, fixed=TRUE) ) {
      stop("Define trees in ", model[i], " with ':'." )
    } 
    #- '~' operator?
    if( !grepl("~", x.simple, fixed=TRUE) ) {
      stop("Define categories in ", model[i], " with '~'." )
    } 
    # Step 2: split by operator
    op.idx <- regexpr("~", x)  
    lhs <- substr(x, 1L, op.idx-1L)
    rhs <- substr(x, op.idx + attr(op.idx, "match.length"), nchar(x) )
    # Step 3: Get list of names for the lhs formula
    out.lhs <- mptmem_parsing_lhs_mpt( lhs = lhs ) 
    # Step 4: Get list of names for the rhs formula with modifiers (if any)
    out.rhs <- mptmem_parsing_rhs_mpt( rhs = rhs )    
    # Step 5: save all things in a list
    for ( j in 1:length( out.lhs ) ) {
      # check whether category was mentioned before:        
      if( names(out.lhs)[j] %in% mpt.tree & out.lhs[[j]]$cat %in% mpt.cat ) {
        branch.idx <- which( names(out.lhs)[j] == mpt.tree & out.lhs[[j]]$cat == mpt.cat )
        branch.no <- max( mpt.branch[ branch.idx ] ) + 1 
      } else {
        branch.no <- 1
      }
      for ( k in 1:length( out.rhs ) ) {
        iterator <- iterator + 1
        #- define things for this loop:
        mpt.type[ iterator ] <- "MPT"
        mpt.tree[ iterator ] <- names(out.lhs)[j]
        mpt.cat[ iterator ]  <- out.lhs[[j]]$cat
        mpt.branch[ iterator ] <- branch.no
        mpt.pathcoef[ iterator ] <- names(out.rhs)[k]
        mpt.present[ iterator ] <- 1
        mpt.parm[ iterator ] <- out.rhs[[k]]$parm 
        mpt.parminv[ iterator ] <- out.rhs[[k]]$parminv 
      } # for-loop rhs
    } # for-loop lhs
  } # for-loop lines
  #- make final list:
  mpt.parse <- list( type = mpt.type, tree = mpt.tree, cat = mpt.cat, branch = mpt.branch, 
    pathcoef = mpt.pathcoef, present = mpt.present, parm = mpt.parm, parminv = mpt.parminv )
  #- some final checks?
  return( mpt.parse )
}

mptmem_parsing_lhs_mpt <- function( lhs = NULL  ) 
{
  #- make outcome list:
  out <- vector("list", 1L)
  #- we split lhs:
  lhs.idx <- regexpr(":", lhs )  
  lhs.lhs <- substr(lhs, 1L, lhs.idx-1L)
  lhs.rhs <- substr(lhs, lhs.idx + attr(lhs.idx, "match.length"), nchar( lhs ) )
  #- left part:
  lhs.lhs_form <- stats::as.formula( paste("~", lhs.lhs ) ) 
  namen <- all.vars( lhs.lhs_form )
  if ( length( namen ) == 1 ) {
    names(out)[1L] <- namen
  } else {
    stop("Only one tree name per line is allowed.")
  }
  # right part:
  lhs.rhs_form <- stats::as.formula( paste("~", lhs.rhs ) ) 
  namen <- all.vars( lhs.rhs_form )
  if ( length( namen ) == 1 ) {
    out[[1L]]$cat <- namen
  } else {
    stop("Only one category name per line is allowed.")
  }
  return(out)
}

mptmem_parsing_rhs_mpt <- function( rhs = NULL  ) 
{
  #- make outcome list:
  out <- list()
  #- we go through the line:
  tmp.string <- gsub("\\s", "", rhs)
  tmp.string.split <- strsplit( tmp.string, "\\*", perl = FALSE )[[1]]
  #- going through tmp.spring.list
  for ( i in 1:length( tmp.string.split ) ) {
    #- temp out object:
    tmp.out <- vector("list", 1L)
    #- get string:
    act.string <- tmp.string.split[i]
    #- make it a formula object:
    act.form <- stats::as.formula( paste("~", act.string ) )    
    #- check whether this is a path or its 'inverse' (e.g. a vs. 1-a)
    ainv.left <- grepl( "(", act.string, fixed = TRUE )
    ainv.right <- grepl( ")", act.string, fixed = TRUE )  
    #- let's go:
    if ( ainv.left & ainv.right ) {
      # name the list and give it an element inv
      names(tmp.out)[1L] <- all.vars( act.form )
      tmp.out[[1L]]$parm <- 0
      tmp.out[[1L]]$parminv <- 1
    } else if ( !(ainv.left & ainv.right) ) {
      names(tmp.out)[1L]$path <- all.vars( act.form )
      tmp.out[[1L]]$parm <- 1
      tmp.out[[1L]]$parminv <- 0
    } else {
      stop("Problem in ", rhs, ". Perhaps a bracket is missing." )
    }
    out <- c( out, tmp.out )
  }
  return( out )
}

##############################################
###         Parsing person part
##############################################

mptmem_parsing_list_person <- function( model = NULL ) 
{
  #- define empty vectors:
  mpt.type <- character(0)
  mpt.lhs <- character(0)
  mpt.op  <- character(0)
  mpt.rhs <- character(0)
  mpt.fixed <- integer(0) 
  mpt.starts <- integer(0) 
  mpt.equal <- character(0) 
  mpt.mod.idx <- integer(0) 
  mpt.free <- integer(0)    
  #- let's go:  
  iterator <- 0
  for ( i in 1:length(model) )  {
    # get line to analyse:
    x <- model[i]
    # which operator is used?
    x.simple <- gsub("\\\".[^\\\"]*\\\"", "LABEL", x)
    # "=~" operator?
    if(grepl("=~", x.simple, fixed=TRUE)) {
      op <- "=~"
    # "~~" operator?
    } else if(grepl("~~", x.simple, fixed=TRUE)) {
      op <- "~~"
    # "~" operator?
    } else if(grepl("~", x.simple, fixed=TRUE)) {
      op <- "~"
    } else {
      stop("Unknown operator is used in ", model[i] )
    }
    # Step 2: split by operator
    op.idx <- regexpr(op, x)
    lhs <- substr(x, 1L, op.idx-1L)
    rhs <- substr(x, op.idx + attr(op.idx, "match.length"), nchar(x) )
    # Step 3: Get list of names for the lhs formula
    out.lhs <- mptmem_parsing_lhs_person( lhs = lhs ) 
    # Step 4: Get list of names for the rhs formula with modifiers (if any)
    out.rhs <- mptmem_parsing_rhs_person( rhs = rhs, op = op )
    # Step 5: save all things in a list
    for ( j in 1:length( out.lhs ) ) {
      for ( k in 1:length( out.rhs ) ) {
        iterator <- iterator + 1
        #- define things for this loop:
        mpt.type[ iterator ] <- "Person"
        mpt.lhs[ iterator ] <- names(out.lhs)[j]
        mpt.fixed[ iterator ]  <- as.numeric(NA)
        mpt.starts[ iterator ] <- as.numeric(NA)
        mpt.equal[ iterator ] <- as.numeric(NA)
        mpt.mod.idx[ iterator ] <- 0
        mpt.free[ iterator ] <- 1L       
        #- Do we need to respect an intercept? :
        if ( out.rhs[[k]]$type == "I") {
          mpt.op[ iterator ]  <- "~1"
          mpt.rhs[ iterator ] <- names(out.lhs)[j]
        } else {
          mpt.op[ iterator ]  <- op
          mpt.rhs[ iterator ] <- names(out.rhs)[k]
        }
        #- Save when fixed:
        if( length( out.rhs[[k]]$fixed ) > 0L ) {
          mpt.fixed[ iterator ] <- out.rhs[[k]]$fixed
          mpt.free[ iterator ] <- 0L
          mpt.mod.idx[ iterator ] <- 1
        }
        #- Save when start:
        if( length( out.rhs[[k]]$starts ) > 0L ) {
          mpt.starts[ iterator ] <- out.rhs[[k]]$starts
          mpt.mod.idx[ iterator ] <- 1
        }
        #- Save when start:
        if( length( out.rhs[[k]]$equal ) > 0L ) {
          mpt.equal[ iterator ] <- out.rhs[[k]]$equal
          mpt.mod.idx[ iterator ] <- 1
        }
      } # for-loop rhs
    } # for-loop lhs
  } # for-loop lines
  #- make final list:
  mpt.parse <- list( type = mpt.type, lhs = mpt.lhs, op = mpt.op, rhs = mpt.rhs, fixed = mpt.fixed, 
    starts = mpt.starts, equal = mpt.equal, mod.idx = mpt.mod.idx, free = mpt.free )
  #- add defined cov terms in revese order:
  mpt.parse <- mptmem_parsing_add_covterms( mpt.parse = mpt.parse )
  return( mpt.parse )
}

mptmem_parsing_add_covterms <- function( mpt.parse = NULL ) 
{
  #- get defined covariance terms:
  idx <- which( mpt.parse$op == "~~"  & mpt.parse$lhs != mpt.parse$rhs )
  lgt.idx <- length( idx )
  if ( lgt.idx > 0L ) {
    #- define empty vectors:
    mpt.type    <- character(0)
    mpt.lhs     <- character(0)
    mpt.op      <- character(0)
    mpt.rhs     <- character(0)
    mpt.fixed   <- integer(0) 
    mpt.starts  <- integer(0) 
    mpt.equal   <- character(0) 
    mpt.mod.idx <- integer(0) 
    mpt.free    <- integer(0)  
    #- loop:
    for ( ii in seq( lgt.idx ) ) {
        idx.ii <- idx[ii]
        mpt.type[ ii ]    <- "Person"
        mpt.lhs[ ii ]     <- mpt.parse$rhs[ idx.ii ]
        mpt.op[ ii ]      <- "~~"
        mpt.rhs[ ii ]     <- mpt.parse$lhs[ idx.ii ]
        mpt.fixed[ ii ]   <- mpt.parse$fixed[ idx.ii ]
        mpt.starts[ ii ]  <- mpt.parse$starts[ idx.ii ]
        mpt.equal[ ii ]   <- mpt.parse$equal[ idx.ii ]
        mpt.mod.idx[ ii ] <- mpt.parse$mod.idx[ idx.ii ]
        mpt.free[ ii ]    <- mpt.parse$free[ idx.ii ]     
    }
    #- add to list:
    mpt.parse$type    <- c(mpt.parse$type,    mpt.type )
    mpt.parse$lhs     <- c(mpt.parse$lhs,     mpt.lhs )
    mpt.parse$op      <- c(mpt.parse$op,      mpt.op )
    mpt.parse$rhs     <- c(mpt.parse$rhs,     mpt.rhs )
    mpt.parse$fixed   <- c(mpt.parse$fixed,   mpt.fixed )
    mpt.parse$starts  <- c(mpt.parse$starts,  mpt.starts ) 
    mpt.parse$equal   <- c(mpt.parse$equal,   mpt.equal ) 
    mpt.parse$mod.idx <- c(mpt.parse$mod.idx, mpt.mod.idx ) 
    mpt.parse$free    <- c(mpt.parse$free,    mpt.free ) 
  }
  return( mpt.parse )
}

mptmem_parsing_lhs_person <- function( lhs = NULL  ) 
{
  #- make outcome list:
  out <- vector("list", 1L)
  lhs.form <- stats::as.formula( paste("~", lhs ) ) # use formula here to get c vs cc
  #- get names: 
  namen <- all.vars( lhs.form[[2L]] )
  if ( length( names ) == 1 ) {
    names(out)[1L] <- namen
  } else {
    stop("Only one left-hand side variable is allowed.")
  }
  return(out)
}

mptmem_parsing_rhs_person <- function( rhs = NULL, op = NULL ) 
{
  #- make outcome list:
  out <- list()
  #- we go through the line:
  tmp.string <- gsub("\\s", "", rhs)
  tmp.string.split <- strsplit( tmp.string, "\\+", perl = FALSE )[[1]]
  for ( i in 1:length( tmp.string.split ) ) {
    #- temp out object:
    tmp.out <- vector("list", 1L) 
    #- get actual string:
    act.string <- tmp.string.split[i]
    #- make it a formula object:
    act.form <- stats::as.formula( paste("~", act.string ) )
    #- is there a modifier and if so then get it:
    modifier <- grepl( "*", act.string, fixed = TRUE )
    if ( modifier ) {
      mod <- mptmem_parsing_getmodifier_person( modifier = act.form[[2L]][[2L]] )
      if( names(mod) == "fixed" ) { 
        tmp.out[[1L]]$fixed <- mod[[1L]]
      } else if ( names(mod) == "equal") {
        tmp.out[[1L]]$equal <- mod[[1L]]
      } else if ( names(mod) == "start" ) {
        tmp.out[[1L]]$starts <- mod[[1L]]
      } else {
        stop("There is a problem with", act.string )
      }
      #- consider intercepts:
      names(tmp.out)[1L] <- as.character( act.form[[2L]][[3L]] )
      if ( is.numeric( act.form[[2L]][[3L]] ) & op == "~" ) {
        tmp.out[[1L]]$type <- "I"
      } else {
        tmp.out[[1L]]$type <- "notI"
      }
    } else {
      names(tmp.out)[1L] <- as.character( act.form[[2L]] ) #all.vars( act.form[[2L]] ) 
      #- consider intercepts:
      if ( is.numeric( act.form[[2L]] ) & op == "~" ) {
        tmp.out[[1L]]$type <- "I"
      } else {
        tmp.out[[1L]]$type <- "notI"
      }
    }
    out <- c( out, tmp.out )
  } # for-loop
  return( out )
}

mptmem_parsing_getmodifier_person <- function( modifier = NULL ) 
{
  if( length( modifier ) == 1L ) {
        if( is.numeric(modifier) )  {
          return( list( fixed = modifier) )
        } else if ( is.symbol(modifier) ) {
          return( list( equal = as.character(modifier)) )
        } else {
          stop("Cannot parse the modifier:", modifier, "\n")
        }
  } else if( modifier[[1L]] == "start" ) { 
    cof <- unlist( lapply(as.list( modifier )[-1], eval, envir = NULL, enclos = NULL ) )
    return( list( start = cof ) )
  } else {
    stop("Cannot parse the modifier:", modifier, "\n")
  }
}