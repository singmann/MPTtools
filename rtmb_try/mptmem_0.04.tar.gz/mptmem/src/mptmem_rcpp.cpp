//// File Name: MELS_Rcpp.cpp
//// File Version: 0.889

// [[Rcpp__interfaces(r, cpp)]]  substitute "__" by "::"
// for exporting Rcpp functions for use in another package

// [[Rcpp::depends(RcppArmadillo)]]

#include <RcppArmadillo.h>
#include <Rcpp.h>    

using namespace Rcpp;
using namespace arma;

///***********************
//**  multinomial part
///***********************

//  const bool byrow = true

// [[Rcpp::export]]

arma::mat mptmem_utils_matrix2vector( arma::mat m,
  const bool byrow = true )
{
  
  if (byrow) {
    return m.as_row();
  } else {
    return m.as_col();
  }
  
}

// [[Rcpp::export]]

Rcpp::NumericMatrix mptmem_utils_submat( Rcpp::NumericMatrix X, 
                                         Rcpp::NumericVector T,
                                         double index ) 
{
    arma::mat Xmat( X.begin(), X.nrow(), X.ncol(), false);
    arma::colvec tIdx( T.begin(), T.size(), false); 
    arma::mat y = Xmat.rows( find( tIdx == index ) );
    Rcpp::NumericMatrix out = wrap(y);
    return out;
}

// [[Rcpp::export]]

Rcpp::NumericVector mptmem_utils_vectorprod( Rcpp::NumericVector X, 
                                              Rcpp::NumericVector Y ) 
{
    int p = X.length();
    Rcpp::NumericVector out(p);
    for(int ii = 0;ii<p;ii++) {
        out(ii)=X(ii)*Y(ii);
    }
    return out;
}

// [[Rcpp::export]]

double mptmem_utils_sumNP( Rcpp::NumericVector njk,
                            Rcpp::NumericVector Pjk,
                            bool log )
{
    
    // number of subcategories
    int k = njk.length();
    
    // lets go:
    double out = 0;
    for (int ii=0; ii<k; ii++){
        double iiP = Pjk(ii);
        out += njk(ii)*std::log(iiP);
    }
    // exponentiate if log = FALSE:
    if ( log == FALSE ) {
        out = std::exp( out );
    }   

    //-- output
    return out;
}

// [[Rcpp::export]]

Rcpp::NumericVector mptmem_llfct_prepare_rcpp( Rcpp::NumericVector us, 
                                                String type_mpt ) 
{
    // number of MPT parms:
    int npar = us.size();
    // make tParm object:
    Rcpp::NumericVector theta( npar );
    // for each MPT parm vector we compute the linear predictor:
    if ( type_mpt == "logit" ) {
        for (int i=0;i<npar;i++) {
            theta(i) = 1/( 1 + exp( -1*us(i) ) );
        } 
    } 
    if ( type_mpt == "probit" ) {
        theta = Rcpp::pnorm( us );
    } 
    // make output:
    return theta;
}

// [[Rcpp::export]]

Rcpp::NumericVector mptmem_llfct_catprob_rcpp( Rcpp::NumericVector theta,
                                                Rcpp::NumericMatrix probmatrix,
                                                Rcpp::NumericMatrix catmatrix )
{
    // extract no. of parms:
    int S = theta.length();
    // extract no. of independent sub categories:
    int K = catmatrix.nrow();
    // vector for over probabilities:
    Rcpp::NumericVector P_Ck(K);
    // iterate over K, make indices for matrices:
    int idx1 = 0;
    int idx2 = S - 1;
    for (int kk=0;kk<K;kk++) {
        // get no. of subtrees in subcategory k:
        int Ijk = catmatrix(kk,2);
        // iterate over Ijk:
        for (int ii=0;ii<Ijk;ii++) {
            // get submatrix:
            Rcpp::NumericMatrix AB = probmatrix( Range(idx1,idx2), Range(0,4) );
            // get single path prob:
            double tmp1 = 1;
            double tmp2 = 1;
            for (int ss=0;ss<S;ss++) {
                if ( AB(ss,3) > 0 ) {
                    tmp1 = tmp1*pow( theta(ss), AB(ss,3) ); 
                }
                if ( AB(ss,4) > 0 ) {
                    tmp2 = tmp2*pow( 1 - theta(ss), AB(ss,4) ); 
                }
            }
            idx1 = idx1 + S;
            idx2 = idx2 + S;
            P_Ck(kk) = P_Ck(kk) + tmp1*tmp2;        
        } // Ijk
    } // K
    return P_Ck;
}

// [[Rcpp::export]]

Rcpp::NumericVector mptmem_llfct_data_rcpp( Rcpp::NumericMatrix pts,
                                             Rcpp::NumericVector tCatDat,
                                             Rcpp::NumericMatrix probmatrix,
                                             Rcpp::NumericMatrix catmatrix,             
                                             String type_mpt )
{
    // make output vector:
    int n = pts.nrow();
    Rcpp::NumericVector out(n);
    // we iterate through the pts:
    for(int ii=0; ii<n;ii++) {
        // get points:
        Rcpp::NumericVector us = pts(ii,_);
        // get tParm vector:
        Rcpp::NumericVector theta = mptmem_llfct_prepare_rcpp( us = us, type_mpt = type_mpt );
        // compute prob of a category system:
        Rcpp::NumericVector P_Ck = mptmem_llfct_catprob_rcpp( theta = theta, 
            probmatrix = probmatrix, catmatrix = catmatrix );
        // compute loglik data:
        out(ii) = mptmem_utils_sumNP( tCatDat, P_Ck, FALSE );
    }
    return out;
}

// [[Rcpp::export]]

double mptmem_derivatives_llfct_rcpp( Rcpp::NumericVector us, 
                                      Rcpp::NumericVector tCatDat,
                                      arma::colvec tCovDat,
                                      Rcpp::NumericMatrix probmatrix,
                                      Rcpp::NumericMatrix catmatrix,
                                      String type_mpt,
                                      arma::mat iSIGMA,
                                      arma::colvec MU,
                                      arma::mat GAM,
                                      arma::mat S,
                                      arma::mat LAM,
                                      arma::mat PSI,
                                      String mat,
                                      arma::rowvec pos,
                                      arma::rowvec usiSIGMA )
{
    // set derivative to zero:
    double tmp = 0;
    // make a string vector: 
    if ( mat == "MU" ) { 
        // 1_ij - matrix:
        int p = MU.n_rows;
        arma::colvec ONE_ij = zeros( p ); 
        ONE_ij( pos(0,0) - 1, 0 ) = 1;
        // derivative: 
        arma::mat res = usiSIGMA * ONE_ij;
        tmp = res(0,0); 
    }
    if ( mat == "GAM" ) { 
        // 1_ij - matrix:
        int p = GAM.n_rows;
        int q = GAM.n_cols;
        arma::mat ONE_ij = zeros( p, q );
        ONE_ij( pos(0,0) - 1 , pos(0,1) - 1 ) = 1;
        // derivative: 
        arma::mat res = usiSIGMA * (ONE_ij * tCovDat );
        tmp = res(0,0); 
    }
    if ( mat == "SIGMA" ) {
        // 1_ij - matrix
        int p = iSIGMA.n_cols;
        arma::mat ONE_ij = zeros( p, p );
        ONE_ij( pos(0,0) - 1 , pos(0,1) - 1 ) = 1;
        // derivative: 
        arma::mat dSIGMA = ONE_ij + ONE_ij.t() - ONE_ij * ONE_ij;
        // true ll derivative:
        double pt1 = -0.5*trace( iSIGMA * dSIGMA );
        arma::mat pt2 = 0.5*( usiSIGMA * dSIGMA * usiSIGMA.t() );
        tmp = pt1 + pt2(0,0); 
    }
    if ( mat == "S" ) {
        // 1_ij - matrix
        int p = iSIGMA.n_cols;
        arma::mat ONE_ij = zeros( p, p );
        ONE_ij( pos(0,0) - 1 , pos(0,1) - 1 ) = 1;
        // derivative: 
        arma::mat dSIGMA = ONE_ij.t()*S + S.t()*ONE_ij;
        // true ll derivative:
        double pt1 = -0.5*trace( iSIGMA * dSIGMA );
        arma::mat pt2 = 0.5*( usiSIGMA * dSIGMA * usiSIGMA.t() );
        tmp = pt1 + pt2(0,0); 
    }
    if ( mat == "LAM" ) {
        // 1_ij - matrix
        int p = LAM.n_rows;
        arma::mat ONE_ij = zeros( p, 1 ); 
        ONE_ij( pos(0,0) - 1, 0 ) = 1;
        // derivative: 
        arma::mat dSIGMA = ONE_ij*LAM.t() + LAM*ONE_ij.t();
        // true ll derivative:
        double pt1 = -0.5*trace( iSIGMA * dSIGMA );
        arma::mat pt2 = 0.5*( usiSIGMA * dSIGMA * usiSIGMA.t() );
        tmp = pt1 + pt2(0,0); 
    }
    if ( mat == "PSI" ) {
        // 1_ij - matrix
        int p = iSIGMA.n_cols;
        arma::mat ONE_ij = zeros( p, p );
        ONE_ij( pos(0,0) - 1 , pos(0,1) - 1 ) = 1;
        // derivative: 
        arma::mat dSIGMA = ONE_ij;
        // true ll derivative:
        double pt1 = -0.5*trace( iSIGMA * dSIGMA );
        arma::mat pt2 = 0.5*( usiSIGMA * dSIGMA * usiSIGMA.t() );
        tmp = pt1 + pt2(0,0); 
    }
    // output:
    return tmp;
} 

// [[Rcpp::export]]

int mptmem_getmaxcol_rcpp( arma::mat position, int index )
{
    arma::colvec pos_column = position.col( index );
    int nop = pos_column.max();
    return nop;
}

// [[Rcpp::export]]

Rcpp::NumericMatrix mptmem_gradient_data_rcpp( Rcpp::NumericMatrix pts, 
                                               Rcpp::NumericVector tCatDat,
                                               arma::colvec tCovDat,
                                               Rcpp::NumericVector tPerDat,
                                               Rcpp::StringVector matname,
                                               arma::mat position,
                                               Rcpp::NumericMatrix probmatrix,
                                               Rcpp::NumericMatrix catmatrix,
                                               String type_mpt,
                                               arma::mat iSIGMA,
                                               arma::colvec MU,
                                               arma::mat GAM,
                                               arma::mat S,
                                               arma::mat LAM,
                                               arma::mat PSI,
                                               Rcpp::NumericVector wghexp, 
                                               Rcpp::NumericVector den,
                                               bool qmc )
{
    // make output matrix:
    double der = 0;
    int n = pts.nrow();
    int nop = mptmem_getmaxcol_rcpp( position = position, 2 );
    int npp = position.n_rows;
    Rcpp::NumericMatrix out( n, nop + 1 );
    // compute loglik-values:
    Rcpp::NumericVector res = mptmem_llfct_data_rcpp( pts = pts, tCatDat = tCatDat, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt );
    // iterate across points:
    for(int ii=0; ii<n;ii++) {
        // get points:
        Rcpp::NumericVector u = pts(ii,_);
        Rcpp::NumericVector theta = u;
        // compute approximation of the log-likelihood:
        double fii = res(ii)*wghexp(ii)*den(ii);
        out( ii, 0 ) = fii;
        // some pre computation:
        Rcpp::NumericVector pt = u - tPerDat;
        arma::colvec pot = as<arma::colvec>(pt);
        //arma::colvec pt = ut - tPerDat; 
        arma::rowvec usiSIGMA = pot.t()*iSIGMA;
        // iterate across gradient values for this point:
        for (int jj=0; jj<npp; jj++) {
            // get information for derivative
            String mat = matname( jj );
            arma::rowvec pos = position.row( jj );
            int idx = pos(0,2) - 1;
            // compute derivative     
            if ( mat == "MU") {
                der = usiSIGMA( 0, pos( 0, 0) - 1 );
            }
            else {
                der = mptmem_derivatives_llfct_rcpp( u = u, tCatDat = tCatDat, tCovDat = tCovDat,
                    probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
                    iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI, 
                    mat = mat, pos = pos, usiSIGMA = usiSIGMA );  
            }   
            if ( qmc ) {
               out( ii, idx + 1 ) = out( ii, idx + 1 ) + der; 
            } else {
               out( ii, idx + 1 ) = out( ii, idx + 1 ) + der*fii ;
            }
            
        } // jj         
    } // ii
    return out;
}

// [[Rcpp::export]]

double mptmem_secondderivatives_llfct_rcpp( Rcpp::NumericVector us, 
                                            Rcpp::NumericVector tCatDat,
                                            arma::colvec tCovDat,
                                            Rcpp::NumericMatrix probmatrix,
                                            Rcpp::NumericMatrix catmatrix,
                                            String type_mpt,
                                            arma::mat iSIGMA,
                                            arma::colvec MU,
                                            arma::mat GAM,
                                            arma::mat S,
                                            arma::mat LAM,
                                            arma::mat PSI,
                                            String matjj,
                                            arma::rowvec posjj,
                                            String matpp,
                                            arma::rowvec pospp,
                                            arma::rowvec usiSIGMA )
{
    // set derivative to zero:
    double tmp = 0;
    // make a string vector:
    if ( matjj == "SIGMA" && matpp == "SIGMA" ) {
        int p = iSIGMA.n_cols;
        // 1jj - matrix
        arma::mat ONEjj = zeros( p, p );
        ONEjj( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;
        arma::mat dSIGMAjj = ONEjj + ONEjj.t() - ONEjj * ONEjj;
        // 1pp - matrix
        arma::mat ONEpp = zeros( p, p );
        ONEpp( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;
        arma::mat dSIGMApp = ONEpp + ONEpp.t() - ONEpp * ONEpp;
        // true ll derivative:
        double pt1 = 0.5*trace( ( iSIGMA * dSIGMAjj ) * ( iSIGMA * dSIGMApp ) );
        arma::mat pt2 = -1 * usiSIGMA *( dSIGMAjj * iSIGMA * dSIGMApp ) * usiSIGMA.t();
        tmp = pt1 + pt2(0,0); 
    } 
    if ( matjj == "S" && matpp == "S" ) {
        int p = iSIGMA.n_cols;
        // 1jj - matrix
        arma::mat ONEjj = zeros( p, p );
        ONEjj( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;
        arma::mat dSIGMAjj = ONEjj.t()*S + S.t()*ONEjj;
        // 1pp - matrix
        arma::mat ONEpp = zeros( p, p );
        ONEpp( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;
        arma::mat dSIGMApp = ONEpp.t()*S + S.t()*ONEpp;
        // additonal term:
        arma::mat dSIGMAjjpp = ONEjj.t()*ONEpp + ONEpp.t()*ONEjj;
        // true ll derivative:
        double pt1 = 0.5*trace( iSIGMA*dSIGMAjj*iSIGMA*dSIGMApp - iSIGMA*dSIGMAjjpp );
        arma::mat pt2 = usiSIGMA*( 0.5*dSIGMAjjpp - dSIGMAjj*iSIGMA*dSIGMApp )*usiSIGMA.t();
        tmp = pt1 + pt2(0,0); 
    } 
    if ( matjj == "LAM" && matpp == "LAM" ) {
        int p = LAM.n_rows;
        // 1jj - matrix
        arma::mat ONEjj = zeros( p, 1 );
        ONEjj( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;
        arma::mat dSIGMAjj = ONEjj*LAM.t() + LAM*ONEjj.t();
        // 1pp - matrix
        arma::mat ONEpp = zeros( p, 1 );
        ONEpp( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;
        arma::mat dSIGMApp = ONEpp*LAM.t() + LAM*ONEpp.t();;
        // additonal term:
        arma::mat dSIGMAjjpp = ONEjj*ONEpp.t() + ONEpp*ONEjj.t();
        // true ll derivative:
        double pt1 = 0.5*trace( iSIGMA*dSIGMAjj*iSIGMA*dSIGMApp - iSIGMA*dSIGMAjjpp );
        arma::mat pt2 = usiSIGMA*( 0.5*dSIGMAjjpp - dSIGMAjj*iSIGMA*dSIGMApp )*usiSIGMA.t();
        tmp = pt1 + pt2(0,0); 
    } 
    // make a string vector:
    if ( matjj == "PSI" && matpp == "PSI" ) {
        int p = iSIGMA.n_cols;
        // 1jj - matrix
        arma::mat ONEjj = zeros( p, p );
        ONEjj( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;
        arma::mat dSIGMAjj = ONEjj;
        // 1pp - matrix
        arma::mat ONEpp = zeros( p, p );
        ONEpp( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;
        arma::mat dSIGMApp = ONEpp;
        // true ll derivative:
        double pt1 = 0.5*trace( ( iSIGMA * dSIGMAjj ) * ( iSIGMA * dSIGMApp ) );
        arma::mat pt2 = -1 * usiSIGMA *( dSIGMAjj * iSIGMA * dSIGMApp ) * usiSIGMA.t();
        tmp = pt1 + pt2(0,0); 
    } 
    if ( matjj == "MU" && matpp == "MU" ) { 
        int p = MU.n_rows;
        // 1jj - matrix:
        arma::colvec ONEjj = zeros( p ); 
        ONEjj( posjj(0,0) - 1, 0 ) = 1;
        // 1jj - matrix:
        arma::colvec ONEpp = zeros( p ); 
        ONEpp( pospp(0,0) - 1, 0 ) = 1;
        // derivative: 
        arma::mat res = -1 * ONEpp.t() * iSIGMA * ONEjj;
        tmp = res(0,0); 
    }
    if ( matjj == "GAM" && matpp == "GAM" ) { 
        // 1_ij - matrix:
        int p = GAM.n_rows;
        int q = GAM.n_cols;
        // 1jj-matrix:
        arma::mat ONEjj = zeros( p, q );
        ONEjj( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;
        // 1pp-matrix:
        arma::mat ONEpp = zeros( p, q );
        ONEpp( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;
        // derivative: 
        arma::mat tmp1 = ONEjj * tCovDat;
        arma::mat tmp2 = ONEpp * tCovDat;
        arma::mat res = -1 * tmp2.t() * iSIGMA * tmp1;
        tmp = res(0,0); 
    }
    // #############################################################
    if ( (matjj == "SIGMA" && matpp == "MU") | (matjj == "MU" && matpp == "SIGMA") ) {
      // matrix and derivative for SIGMA
      int p = iSIGMA.n_cols;
      arma::mat ONE_SIG = zeros( p, p ); 
      if ( matjj == "SIGMA" ) {
        ONE_SIG( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_SIG( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_SIG + ONE_SIG.t() - ONE_SIG * ONE_SIG;
      // matrix and derivative for MU
      int q = MU.n_rows;
      arma::colvec ONE_MU = zeros( q );
      if ( matjj == "MU" ) {
        ONE_MU( posjj(0,0) - 1, 0 ) = 1;  
      } else {
        ONE_MU( pospp(0,0) - 1, 0 ) = 1;
      }  
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * ONE_MU;
      tmp = res(0,0); 
    }
    if ( (matjj == "S" && matpp == "MU") | (matjj == "MU" && matpp == "S") ) {
      // matrix and derivative for S
      int p = iSIGMA.n_cols;
      arma::mat ONE_S = zeros( p, p ); 
      if ( matjj == "S" ) {
        ONE_S( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_S( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_S.t()*S + S.t()*ONE_S;
      // matrix and derivative for MU
      int q = MU.n_rows;
      arma::colvec ONE_MU = zeros( q );
      if ( matjj == "MU" ) {
        ONE_MU( posjj(0,0) - 1, 0 ) = 1;  
      } else {
        ONE_MU( pospp(0,0) - 1, 0 ) = 1;
      }  
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * ONE_MU;
      tmp = res(0,0); 
    }
    if ( (matjj == "LAM" && matpp == "MU") | (matjj == "MU" && matpp == "LAM") ) {
      // matrix and derivative for LAM
      int p = LAM.n_rows;
      arma::mat ONE_LAM = zeros( p, 1 ); 
      if ( matjj == "LAM" ) {
        ONE_LAM( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_LAM( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_LAM*LAM.t() + LAM*ONE_LAM.t();
      // matrix and derivative for MU
      int q = MU.n_rows;
      arma::colvec ONE_MU = zeros( q );
      if ( matjj == "MU" ) {
        ONE_MU( posjj(0,0) - 1, 0 ) = 1;  
      } else {
        ONE_MU( pospp(0,0) - 1, 0 ) = 1;
      }  
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * ONE_MU;
      tmp = res(0,0); 
    }
    if ( (matjj == "PSI" && matpp == "MU") | (matjj == "MU" && matpp == "PSI") ) {
      // matrix and derivative for PSI
      int p = iSIGMA.n_cols;
      arma::mat ONE_PSI = zeros( p, p ); 
      if ( matjj == "PSI" ) {
        ONE_PSI( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_PSI( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_PSI;
      // matrix and derivative for MU
      int q = MU.n_rows;
      arma::colvec ONE_MU = zeros( q );
      if ( matjj == "MU" ) {
        ONE_MU( posjj(0,0) - 1, 0 ) = 1;  
      } else {
        ONE_MU( pospp(0,0) - 1, 0 ) = 1;
      }  
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * ONE_MU;
      tmp = res(0,0); 
    }
    // #############################################################
    if ( (matjj == "SIGMA" && matpp == "GAM") | (matjj == "GAM" && matpp == "SIGMA") ) {
      // matrix and derivative for SIGMA
      int p = iSIGMA.n_cols;
      arma::mat ONE_SIG = zeros( p, p ); 
      if ( matjj == "SIGMA" ) {
        ONE_SIG( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_SIG( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_SIG + ONE_SIG.t() - ONE_SIG * ONE_SIG;
      // matrix and derivative for GAM
      int r = GAM.n_rows;
      int q = GAM.n_cols;
      arma::mat ONE_GAM = zeros( r, q );
      if ( matjj == "GAM" ) {
        ONE_GAM( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_GAM( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;  
      }  
      arma::mat dGAM = ONE_GAM * tCovDat;
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * dGAM;
      tmp = res(0,0); 
    }
    if ( (matjj == "S" && matpp == "GAM") | (matjj == "GAM" && matpp == "S") ) {
      // matrix and derivative for S
      int p = iSIGMA.n_cols;
      arma::mat ONE_S = zeros( p, p ); 
      if ( matjj == "S" ) {
        ONE_S( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_S( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_S.t()*S + S.t()*ONE_S;
      // matrix and derivative for GAM
      int r = GAM.n_rows;
      int q = GAM.n_cols;
      arma::mat ONE_GAM = zeros( r, q );
      if ( matjj == "GAM" ) {
        ONE_GAM( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_GAM( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;  
      }  
      arma::mat dGAM = ONE_GAM * tCovDat;
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * dGAM;
      tmp = res(0,0); 
    }
    if ( (matjj == "LAM" && matpp == "GAM") | (matjj == "GAM" && matpp == "LAM") ) {
      // matrix and derivative for LAM
      int p = LAM.n_rows;
      arma::mat ONE_LAM = zeros( p, 1 ); 
      if ( matjj == "LAM" ) {
        ONE_LAM( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_LAM( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_LAM*LAM.t() + LAM*ONE_LAM.t();
      // matrix and derivative for GAM
      int r = GAM.n_rows;
      int q = GAM.n_cols;
      arma::mat ONE_GAM = zeros( r, q );
      if ( matjj == "GAM" ) {
        ONE_GAM( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_GAM( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;  
      }  
      arma::mat dGAM = ONE_GAM * tCovDat;
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * dGAM;
      tmp = res(0,0); 
    }
    if ( (matjj == "PSI" && matpp == "GAM") | (matjj == "GAM" && matpp == "PSI") ) {
      // matrix and derivative for PSI
      int p = iSIGMA.n_cols;
      arma::mat ONE_PSI = zeros( p, p ); 
      if ( matjj == "PSI" ) {
        ONE_PSI( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_PSI( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dSIGMA = ONE_PSI;
      // matrix and derivative for GAM
      int r = GAM.n_rows;
      int q = GAM.n_cols;
      arma::mat ONE_GAM = zeros( r, q );
      if ( matjj == "GAM" ) {
        ONE_GAM( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_GAM( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;  
      }  
      arma::mat dGAM = ONE_GAM * tCovDat;
      // true ll derivative:
      arma::mat res = -1 * usiSIGMA * ( dSIGMA * iSIGMA ) * dGAM;
      tmp = res(0,0); 
    }
    // #############################################################
    if ( (matjj == "MU" && matpp == "GAM") | (matjj == "GAM" && matpp == "MU") ) {
      // matrix and derivative for MU
      int p = MU.n_rows;
      arma::colvec ONE_MU = zeros( p );
      if ( matjj == "MU" ) {
        ONE_MU( posjj(0,0) - 1, 0 ) = 1;  
      } else {
        ONE_MU( pospp(0,0) - 1, 0 ) = 1;
      }  
      // matrix and derivative for GAM
      int r = GAM.n_rows;
      int q = GAM.n_cols;
      arma::mat ONE_GAM = zeros( r, q );
      if ( matjj == "GAM" ) {
        ONE_GAM( posjj(0,0) - 1 , posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_GAM( pospp(0,0) - 1 , pospp(0,1) - 1 ) = 1;  
      }  
      arma::mat dGAM = ONE_GAM * tCovDat;
      // true ll derivative:
      arma::mat res = -1 * dGAM.t() * iSIGMA * ONE_MU;
      tmp = res(0,0); 
    }
    // #############################################################
    if ( (matjj == "LAM" && matpp == "PSI") | (matjj == "PSI" && matpp == "LAM") ) {
      // matrix and derivative for LAM
      int p = LAM.n_rows;
      arma::mat ONE_LAM = zeros( p, 1 ); 
      if ( matjj == "LAM" ) {
        ONE_LAM( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_LAM( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dLAM = ONE_LAM*LAM.t() + LAM*ONE_LAM.t();
      // matrix and derivative for PSI
      int q = iSIGMA.n_cols;
      arma::mat ONE_PSI = zeros( q, q ); 
      if ( matjj == "PSI" ) {
        ONE_PSI( posjj(0,0) - 1, posjj(0,1) - 1 ) = 1;  
      } else {
        ONE_PSI( pospp(0,0) - 1, pospp(0,1) - 1 ) = 1;  
      }   
      arma::mat dPSI = ONE_PSI;
      // true ll derivative:
      double pt1 = 0.5*trace( ( iSIGMA * dLAM ) * ( iSIGMA * dPSI ) );
      arma::mat pt2 = -1 * usiSIGMA *( dLAM * iSIGMA * dPSI ) * usiSIGMA.t();
      tmp = pt1 + pt2(0,0); 
    } 
    // output:
    return tmp;
}    

// [[Rcpp::export]]

Rcpp::List mptmem_hessian_data_rcpp( Rcpp::NumericMatrix pts, 
                                     Rcpp::NumericVector tCatDat,
                                     arma::colvec tCovDat,
                                     Rcpp::NumericVector tPerDat,
                                     Rcpp::StringVector matname,
                                     arma::mat position,
                                     Rcpp::NumericMatrix probmatrix,
                                     Rcpp::NumericMatrix catmatrix,
                                     String type_mpt,
                                     arma::mat iSIGMA,
                                     arma::colvec MU,
                                     arma::mat GAM,
                                     arma::mat S,
                                     arma::mat LAM,
                                     arma::mat PSI,
                                     Rcpp::NumericVector wghexp, 
                                     Rcpp::NumericVector den,
                                     bool qmc )
{
    // make output matrix:
    double der = 0;
    double hes = 0;

    int n = pts.nrow();
    int nop = mptmem_getmaxcol_rcpp( position = position, 2 );
    int npp = position.n_rows;
    
    arma::mat outf = zeros( n, 1 );
    arma::mat outg = zeros( n, nop );
    arma::mat outh = zeros( n, nop*nop );

    // compute loglik-values:
    Rcpp::NumericVector res = mptmem_llfct_data_rcpp( pts = pts, tCatDat = tCatDat, 
        probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt );
    
    // iterate across points:
    for(int ii=0; ii<n;ii++) {
    
        // get points:
        Rcpp::NumericVector u = pts(ii,_);
        Rcpp::NumericVector theta = u;
    
        // #######################################
        //   log-likelihood value for this point
        // #######################################

        double fii = res(ii)*wghexp(ii)*den(ii);
    
        // ##############################
        //     gradient for this point
        // ##############################

        // some pre computation:
        Rcpp::NumericVector pt = u - tPerDat;
        arma::colvec pot = as<arma::colvec>(pt);
        //arma::colvec pt = ut - tPerDat; 
        arma::rowvec usiSIGMA = pot.t()*iSIGMA;

        // iterate across gradient values for this point:
        arma::mat tmp_der = zeros(1,nop);
        arma::mat tmp_grad = zeros(1,nop);

        for (int jj=0; jj<npp; jj++) {

          // get information for derivative
          String mat = matname( jj );
          arma::rowvec pos = position.row( jj );
          int idx = pos(0,2) - 1;
          // compute derivative:     
          der = mptmem_derivatives_llfct_rcpp( u = u, tCatDat = tCatDat, tCovDat = tCovDat,
                probmatrix = probmatrix, catmatrix = catmatrix, type_mpt = type_mpt, 
                iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
                mat = mat, pos = pos, usiSIGMA = usiSIGMA );  
          tmp_der( 0,idx) = tmp_der( 0,idx) + der;
          if ( qmc ) {
            tmp_grad(0,idx) = tmp_grad(0,idx) + der; 
          } else {
            tmp_grad(0,idx) = tmp_grad(0,idx) + der*fii;
          }
        } // jj  

        // ##############################
        //     hessian for this point
        // ##############################

        arma::mat tmp_hess = zeros( nop, nop );

        // iterate across gradient values for this point:
        for (int jj=0; jj<npp; jj++) {

          // get information for derivative
          String matjj = matname( jj );
          arma::rowvec posjj = position.row( jj );
          int idxjj = posjj(0,2) - 1;
          double derjj = tmp_der(0,idxjj);

          for ( int pp=jj; pp<npp; pp++) {

            // get information for derivative
            String matpp = matname( pp );
            arma::rowvec pospp = position.row( pp );
            int idxpp = pospp(0,2) - 1;
            double derpp = tmp_der(0,idxpp);

            // compute second derivative:
            hes = mptmem_secondderivatives_llfct_rcpp( u = u, tCatDat = tCatDat, 
              tCovDat = tCovDat, probmatrix = probmatrix, catmatrix = catmatrix, 
              type_mpt = type_mpt, iSIGMA = iSIGMA, MU = MU, GAM = GAM, S = S, LAM = LAM, PSI = PSI,
              matjj = matjj, posjj = posjj, matpp = matpp, pospp = pospp, usiSIGMA = usiSIGMA );

            if ( qmc ) {
                tmp_hess(idxjj,idxpp) = tmp_hess(idxjj,idxpp) + ( hes + derjj*derpp );
            } else {
                tmp_hess(idxjj,idxpp) = tmp_hess(idxjj,idxpp) + ( hes + derjj*derpp )*fii; 
            }          
            tmp_hess(idxpp,idxjj) = tmp_hess(idxjj,idxpp);

         } // pp        
        } // jj          
       
        outf.row(ii) = fii;
        outg.row(ii) = tmp_grad.row(0);
        outh.row(ii) = mptmem_utils_matrix2vector( tmp_hess ).row(0);    
        
    } // ii

    Rcpp::List out = List::create( Rcpp::Named("outf") = outf, 
      Rcpp::Named("outg") = outg, Rcpp::Named("outh") = outh );
    return out;
}
